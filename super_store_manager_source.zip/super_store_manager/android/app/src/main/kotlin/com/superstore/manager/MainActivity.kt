package com.superstore.manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
