import 'package:flutter_test/flutter_test.dart';
import 'package:super_store_manager/core/debt_date.dart';

void main() {
  group('One calendar month debt due date', () {
    test('keeps the same day when it exists in the next month', () {
      expect(addOneCalendarMonth(DateTime(2026, 11, 19)), DateTime(2026, 12, 19));
    });

    test('clamps January 31 to February 28 in a non-leap year', () {
      expect(addOneCalendarMonth(DateTime(2027, 1, 31)), DateTime(2027, 2, 28));
    });

    test('clamps January 31 to February 29 in a leap year', () {
      expect(addOneCalendarMonth(DateTime(2028, 1, 31)), DateTime(2028, 2, 29));
    });

    test('handles year boundary', () {
      expect(addOneCalendarMonth(DateTime(2026, 12, 31)), DateTime(2027, 1, 31));
    });
  });
}
