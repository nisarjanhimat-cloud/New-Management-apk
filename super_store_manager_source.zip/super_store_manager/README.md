# SUPER STORE MANAGER

An offline-first Flutter application source project for a single supermarket owner. The current source includes the core local workflows described below. It is **not yet a production release**: no Android APK has been built or device-tested in this workspace, and the PostgreSQL service is a backend scaffold that is not yet connected to the Flutter app's sync queue.

## Current implementation

- Pashto-first Material interface with a Pashto/English switch and RTL/LTR layout.
- First-run owner password setup and owner-only unlock. Password hashes use PBKDF2-HMAC-SHA256; the SQLCipher database key is stored with Android secure storage.
- Encrypted local SQLite database (SQLCipher) with foreign keys, indexes and financial/activity history.
- Product catalogue, barcode camera scanner, product photos, stock counts, stock purchase, weighted-average purchase cost, low-stock/expiry dashboard indicators.
- POS sales, cash/card split, customer credit sales, discounts and automatic inventory deductions.
- Sales returns and refunds with quantity checks, discounted line-value caps, optional restocking and stock history.
- Individual customer debt records, each with its own calendar-month due date, partial/full payment history and Android local reminder scheduling.
- Customer and supplier records, supplier invoices and partial payment tracking, stock adjustments, expenses and a financial transaction ledger.
- Encrypted password-protected manual backup/restore, Excel workbook export and an English financial-summary PDF.
- PostgreSQL 18 schema and a protected Express API scaffold for owner login, idempotent event ingestion, pull cursors and conflict records.

## Important limitations — read before using for real bookkeeping

1. **No APK is included.** This environment does not have the Flutter SDK or Android SDK, so it cannot compile or test the Android binary. The GitHub Actions workflow can attempt a build after the source is pushed to a GitHub repository. A successful cloud workflow is still required before installing it.
2. **Cloud synchronization is not wired into the mobile app yet.** The Flutter app writes a local `sync_queue`, and the repository contains an API/schema scaffold, but there is no completed Flutter API sync client, conflict-resolution UI, or cloud restore flow. Treat this version as local-only.
3. **This is not fully production-ready accounting software.** The app includes cash/card returns for fully paid sales and inventory adjustments. Returns against credit sales are deliberately blocked because a proper credit-note/debt-adjustment ledger is not implemented. There is no receipt-printer integration, payroll module, supplier statement screen, full audit/reconciliation workflow, or complete date-filtered PDF report pack. Purchase entry currently records one product line per invoice in its user interface.
4. The PDF summary uses English labels and the built-in PDF fonts; Pashto PDF typography is not yet implemented. Excel sheets currently use English column headings.
5. Product photo paths are stored locally, but photo files are not packaged into the encrypted database backup. Back up photos separately before moving phones.
6. Supplier payments and expenses are recorded in the financial ledger, but supplier payment history is not yet displayed as an individual account statement. Opening cash/bank balances are not yet supported, so enter a separate opening-balance workflow before using cash-on-hand totals as a formal balance sheet.
7. Android release builds currently use the debug signing configuration for sideload testing. Do not distribute this APK as a public or permanent production build. A private release keystore and signing configuration are required for production.
8. Exact notifications depend on the Android notification and alarm permissions. The app requests these permissions; Android battery-management settings can still affect delivery. Reminder time uses `Asia/Kabul` at 9:00 AM. For correct business dates, set the phone timezone to Afghanistan/Kabul as well. Samsung devices can impose background and alarm limits; test reminders on the actual phone before relying on them.
9. Biometric unlock, PIN login, remote owner account management and a password reset process are not implemented. The owner password is local to this phone and is separate from the API credentials in the server environment.

## Debt due-date rule

For every credit transaction, the code records a separate debt row and computes the due date by adding one calendar month. It keeps the same day when that day exists in the next month; otherwise it clamps to the last day of the next month (for example, 31 January to 28 February in a non-leap year). Payments are attached to the selected debt row and do not erase payment history. A fully paid debt cancels its scheduled reminder. A partially paid debt replaces its reminder with an updated remaining balance.

The Android notification is scheduled for 9:00 AM on the due date using the `Asia/Kabul` timezone. If the due date is already in the past when the reminder is scheduled, it schedules a reminder for the next morning. Test notification delivery on the actual Samsung phone before relying on it for collections.

## Build an APK using only a phone

This repository contains `.github/workflows/android.yml`.

1. Create or sign in to a GitHub account using the phone browser/app.
2. Create a **private** repository and upload the contents of this project, preserving the folder structure (including `.github/workflows/android.yml`).
3. Open the repository's **Actions** tab, select **Android APK build**, and tap **Run workflow**. A push to the `main` branch also starts a build.
4. Wait for the workflow to finish. If it fails, open the failed step and read the build log; the current source has not yet been validated by an Android build.
5. On a successful run, open the workflow run, find **Artifacts**, and download `super-store-manager-android-apk`. Extract the ZIP on the phone and install `app-release.apk`. Android may ask permission to install unknown apps for the browser/file manager used.

The workflow uses Flutter 3.50.0 and runs the calendar-date unit tests before building. The workflow output is a debug-key-signed sideload build, not a Play Store release.

## Build on a development machine

Install Flutter 3.50.0 stable and Android Studio/Android SDK, then:

```bash
flutter pub get
flutter test
flutter build apk --release
```

The Android Gradle wrapper bootstrap files are generated in CI because they are not committed in this source archive. For a local build, generate them with a Flutter Android project or run `flutter create --platforms=android .` carefully after backing up the Android configuration.

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## First launch

1. Install the APK.
2. Start the app and create the owner password. Use at least 10 characters and store it safely; there is no password-reset service in this local-only build.
3. Allow notifications when Android asks.
4. Enter products and opening stock. Product opening stock is valued at the purchase price saved on the product.
5. Create customers before recording a credit sale.
6. At the POS, split the sale between cash and card. Any remaining amount becomes a separate customer debt and gets its own due date.
7. Use the Debt screen to record partial or full payment against the exact debt item.
8. Create an encrypted backup regularly and keep both the backup file and its password in separate safe places.

## PostgreSQL backend scaffold

The server folder contains PostgreSQL 18 schema and an Express API. It is not deployed by this project and does not currently receive data from the Flutter app.

For a server you control:

```bash
cd server
cp .env.example .env
# Edit .env: use a strong database password, a random JWT_SECRET of at least 48 chars,
# and a unique ADMIN_EMAIL / ADMIN_PASSWORD (at least 14 characters).
docker compose up -d --build
```

Put the API behind HTTPS before exposing it to the internet. Set `PGSSL=true` only when PostgreSQL is configured with a trusted TLS certificate. Keep `.env` private and never commit it. Do not use the sample environment values in production. The API currently has login, sync event push/pull and conflict listing endpoints, but a mobile sync engine and full relational materialization still need implementing.

## Source map

- `lib/core/database_service.dart` — SQLCipher schema and data access setup.
- `lib/core/security_service.dart` — local password hash and DB key storage.
- `lib/core/business_service.dart` — POS, stock, debts, suppliers, purchases, expenses and dashboard calculations.
- `lib/core/debt_date.dart` — calendar-month due-date rule.
- `lib/core/debt_notifications.dart` — local Android reminders.
- `lib/core/backup_service.dart` — encrypted JSON backup/restore.
- `lib/core/report_export_service.dart` — Excel and PDF export.
- `server/` — PostgreSQL schema and API scaffold.
- `test/business_rules_test.dart` — due-date unit tests.

## Before real-world deployment

Complete and test the Flutter/PostgreSQL sync engine, add reconciliation for conflicts, finish returns and inventory corrections, implement receipt printing and a full report suite, configure a permanent release keystore, test on the target Samsung Android version, test backup/restore across a second device, and verify notification delivery after reboot and battery optimization. Do not use the app as the only book of record until those checks are complete.
