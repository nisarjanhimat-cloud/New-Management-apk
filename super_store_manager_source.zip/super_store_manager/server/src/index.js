import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import { rateLimit } from 'express-rate-limit';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const { Pool } = pg;
const required = ['DATABASE_URL', 'JWT_SECRET', 'ADMIN_EMAIL', 'ADMIN_PASSWORD'];
for (const key of required) {
  if (!process.env[key]) throw new Error(`Missing required environment variable: ${key}`);
}
if (process.env.JWT_SECRET.length < 48) throw new Error('JWT_SECRET must be at least 48 characters.');
if (process.env.ADMIN_PASSWORD.length < 14) throw new Error('ADMIN_PASSWORD must be at least 14 characters.');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: true } : undefined });
const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(express.json({ limit: '2mb' }));
const allowedOrigins = (process.env.CORS_ORIGIN || '').split(',').map(x => x.trim()).filter(Boolean);
app.use(cors({ origin: (origin, cb) => {
  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) return cb(null, true);
  return cb(new Error('Origin not allowed'));
} }));
app.use('/v1/auth/login', rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: 'draft-8', legacyHeaders: false }));

async function initialize() {
  const thisDir = path.dirname(fileURLToPath(import.meta.url));
  const schema = await readFile(path.join(thisDir, '../db/schema.sql'), 'utf8');
  await pool.query(schema);
  const email = process.env.ADMIN_EMAIL.toLowerCase().trim();
  const existing = await pool.query('SELECT id FROM owner_users WHERE email=$1', [email]);
  if (existing.rowCount === 0) {
    const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 13);
    await pool.query('INSERT INTO owner_users(email,password_hash) VALUES($1,$2)', [email, hash]);
    console.log('Initial owner account created from environment configuration.');
  }
}

function auth(req, res, next) {
  const token = req.headers.authorization?.startsWith('Bearer ')
    ? req.headers.authorization.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Authentication required.' });
  try {
    req.owner = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid or expired session.' });
  }
}

app.get('/health', async (_req, res) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true, database: 'connected' }); }
  catch { res.status(503).json({ ok: false, database: 'unavailable' }); }
});

app.post('/v1/auth/login', async (req, res) => {
  const email = String(req.body?.email || '').toLowerCase().trim();
  const password = String(req.body?.password || '');
  if (!email || !password) return res.status(400).json({ error: 'Email and password are required.' });
  const result = await pool.query('SELECT id,email,password_hash,is_active FROM owner_users WHERE email=$1 LIMIT 1', [email]);
  const owner = result.rows[0];
  if (!owner || !owner.is_active || !(await bcrypt.compare(password, owner.password_hash))) {
    return res.status(401).json({ error: 'Invalid credentials.' });
  }
  await pool.query('UPDATE owner_users SET last_login_at=now() WHERE id=$1', [owner.id]);
  const token = jwt.sign({ sub: owner.id, role: 'owner' }, process.env.JWT_SECRET, { algorithm: 'HS256', expiresIn: '12h', issuer: 'super-store-manager' });
  return res.json({ access_token: token, token_type: 'Bearer', expires_in: 43200, owner: { id: owner.id, email: owner.email } });
});

app.post('/v1/sync/push', auth, async (req, res) => {
  const clientId = String(req.headers['x-client-id'] || '');
  const events = req.body?.events;
  if (!/^[0-9a-f-]{36}$/i.test(clientId)) return res.status(400).json({ error: 'X-Client-Id must be a UUID.' });
  if (!Array.isArray(events) || events.length > 200) return res.status(400).json({ error: 'events must be an array of at most 200 entries.' });
  const accepted = [];
  const duplicates = [];
  const conflicts = [];
  for (const event of events) {
    if (!event?.id || !event.entity_type || !event.entity_id || !event.operation || !event.payload_json) {
      return res.status(400).json({ error: 'Each event requires id, entity_type, entity_id, operation and payload_json.' });
    }
    let payload;
    try { payload = JSON.parse(event.payload_json); } catch { return res.status(400).json({ error: `Invalid payload JSON for event ${event.id}` }); }
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const added = await client.query(`
        INSERT INTO sync_events(event_id,client_id,owner_user_id,entity_type,entity_id,operation,base_version,payload,created_at)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8::jsonb,COALESCE($9::timestamptz,now()))
        ON CONFLICT(event_id) DO NOTHING RETURNING server_seq`,
      [event.id, clientId, req.owner.sub, event.entity_type, event.entity_id, event.operation,
        Number(event.base_version || 0), JSON.stringify(payload), event.created_at || null]);
      if (added.rowCount === 0) {
        await client.query('COMMIT');
        duplicates.push(event.id);
        continue;
      }
      const mutable = new Set(['product', 'customer', 'supplier', 'category']);
      if (mutable.has(event.entity_type) && event.operation !== 'DELETE') {
        const current = await client.query(`SELECT record_version FROM sync_records
          WHERE owner_user_id=$1 AND entity_type=$2 AND entity_id=$3 FOR UPDATE`,
        [req.owner.sub, event.entity_type, event.entity_id]);
        const actual = current.rowCount ? Number(current.rows[0].record_version) : 0;
        const expected = Number(event.base_version || 0);
        if (actual !== expected) {
          await client.query(`INSERT INTO sync_conflicts(owner_user_id,event_id,entity_type,entity_id,expected_version,actual_version,payload)
            VALUES($1,$2,$3,$4,$5,$6,$7::jsonb)`,
          [req.owner.sub, event.id, event.entity_type, event.entity_id, expected, actual, JSON.stringify(payload)]);
          conflicts.push({ id: event.id, entity_type: event.entity_type, entity_id: event.entity_id, expected_version: expected, actual_version: actual });
        } else {
          await client.query(`INSERT INTO sync_records(owner_user_id,entity_type,entity_id,record_version,payload)
            VALUES($1,$2,$3,$4,$5::jsonb)
            ON CONFLICT(owner_user_id,entity_type,entity_id) DO UPDATE
            SET record_version=EXCLUDED.record_version,payload=EXCLUDED.payload,updated_at=now()`,
          [req.owner.sub, event.entity_type, event.entity_id, actual + 1, JSON.stringify(payload)]);
          accepted.push(event.id);
        }
      } else {
        // Financial events are append-only. The unique event id makes retries idempotent.
        accepted.push(event.id);
      }
      await client.query('COMMIT');
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
  return res.json({ accepted, duplicates, conflicts });
});

app.get('/v1/sync/pull', auth, async (req, res) => {
  const cursor = Math.max(0, Number.parseInt(String(req.query.cursor || '0'), 10) || 0);
  const limit = Math.min(500, Math.max(1, Number.parseInt(String(req.query.limit || '200'), 10) || 200));
  const result = await pool.query(`
    SELECT server_seq,event_id,client_id,entity_type,entity_id,operation,base_version,payload,created_at
    FROM sync_events WHERE owner_user_id=$1 AND server_seq>$2
    ORDER BY server_seq LIMIT $3`, [req.owner.sub, cursor, limit]);
  const nextCursor = result.rowCount ? Number(result.rows[result.rowCount - 1].server_seq) : cursor;
  return res.json({ events: result.rows, next_cursor: nextCursor, has_more: result.rowCount === limit });
});

app.get('/v1/sync/conflicts', auth, async (req, res) => {
  const result = await pool.query(`SELECT id,event_id,entity_type,entity_id,expected_version,actual_version,payload,created_at
    FROM sync_conflicts WHERE owner_user_id=$1 AND resolved_at IS NULL ORDER BY id DESC LIMIT 200`, [req.owner.sub]);
  res.json({ conflicts: result.rows });
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ error: 'Internal server error.' });
});

await initialize();
const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => console.log(`Super Store Manager API listening on ${port}`));
