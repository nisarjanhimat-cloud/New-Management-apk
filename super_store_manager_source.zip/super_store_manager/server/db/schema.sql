CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS owner_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  password_hash text NOT NULL,
  role text NOT NULL DEFAULT 'owner' CHECK (role = 'owner'),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_login_at timestamptz
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), owner_user_id uuid NOT NULL REFERENCES owner_users(id),
  display_name text NOT NULL, role text NOT NULL DEFAULT 'owner', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(), UNIQUE(owner_user_id, name)
);
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), name text NOT NULL,
  barcode text, category_id uuid REFERENCES categories(id), category_name text,
  purchase_price bigint NOT NULL CHECK(purchase_price >= 0), selling_price bigint NOT NULL CHECK(selling_price >= 0),
  quantity integer NOT NULL DEFAULT 0 CHECK(quantity >= 0), minimum_quantity integer NOT NULL DEFAULT 0 CHECK(minimum_quantity >= 0),
  expiry_date date, image_path text, is_archived boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(owner_user_id, barcode)
);
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), name text NOT NULL,
  phone text, address text, is_archived boolean NOT NULL DEFAULT false, version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS suppliers (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), name text NOT NULL,
  phone text, address text, is_archived boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sales (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), customer_id uuid REFERENCES customers(id),
  subtotal bigint NOT NULL CHECK(subtotal >= 0), discount bigint NOT NULL DEFAULT 0 CHECK(discount >= 0),
  total_amount bigint NOT NULL CHECK(total_amount >= 0), cash_received bigint NOT NULL DEFAULT 0,
  card_received bigint NOT NULL DEFAULT 0, credit_amount bigint NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'COMPLETED', created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS sale_items (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), sale_id uuid NOT NULL REFERENCES sales(id),
  product_id uuid NOT NULL REFERENCES products(id), product_name text NOT NULL, quantity integer NOT NULL CHECK(quantity > 0),
  unit_price bigint NOT NULL CHECK(unit_price >= 0), unit_cost bigint NOT NULL CHECK(unit_cost >= 0), line_total bigint NOT NULL CHECK(line_total >= 0)
);
CREATE TABLE IF NOT EXISTS customer_debts (
  id bigserial PRIMARY KEY, public_id uuid NOT NULL UNIQUE, owner_user_id uuid NOT NULL REFERENCES owner_users(id),
  customer_id uuid NOT NULL REFERENCES customers(id), sale_id uuid REFERENCES sales(id),
  original_amount bigint NOT NULL CHECK(original_amount > 0), paid_amount bigint NOT NULL DEFAULT 0 CHECK(paid_amount >= 0),
  due_at timestamptz NOT NULL, status text NOT NULL CHECK(status IN ('OPEN','PARTIAL','PAID')),
  created_at timestamptz NOT NULL, updated_at timestamptz NOT NULL,
  CHECK(paid_amount <= original_amount)
);
CREATE TABLE IF NOT EXISTS debt_payments (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), debt_id bigint NOT NULL REFERENCES customer_debts(id),
  customer_id uuid NOT NULL REFERENCES customers(id), amount bigint NOT NULL CHECK(amount > 0),
  payment_method text NOT NULL DEFAULT 'CASH', note text, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS purchases (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), supplier_id uuid REFERENCES suppliers(id),
  invoice_number text, total_amount bigint NOT NULL CHECK(total_amount >= 0), amount_paid bigint NOT NULL DEFAULT 0 CHECK(amount_paid >= 0),
  purchase_date timestamptz NOT NULL, note text, created_at timestamptz NOT NULL,
  CHECK(amount_paid <= total_amount)
);
CREATE TABLE IF NOT EXISTS purchase_items (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), purchase_id uuid NOT NULL REFERENCES purchases(id),
  product_id uuid NOT NULL REFERENCES products(id), quantity integer NOT NULL CHECK(quantity > 0),
  unit_cost bigint NOT NULL CHECK(unit_cost >= 0), line_total bigint NOT NULL CHECK(line_total >= 0)
);
CREATE TABLE IF NOT EXISTS inventory_transactions (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), product_id uuid NOT NULL REFERENCES products(id),
  transaction_type text NOT NULL, quantity_delta integer NOT NULL, unit_cost bigint NOT NULL DEFAULT 0,
  reference_type text, reference_id uuid, note text, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS sales_returns (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), sale_id uuid NOT NULL REFERENCES sales(id),
  sale_item_id uuid NOT NULL REFERENCES sale_items(id), quantity integer NOT NULL CHECK(quantity > 0),
  refund_amount bigint NOT NULL CHECK(refund_amount >= 0), restock boolean NOT NULL DEFAULT true,
  reason text, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), title text NOT NULL,
  category text, amount bigint NOT NULL CHECK(amount > 0), note text, expense_date timestamptz NOT NULL, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS financial_transactions (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), transaction_type text NOT NULL,
  direction text NOT NULL CHECK(direction IN ('IN','OUT')), amount bigint NOT NULL CHECK(amount > 0),
  reference_type text, reference_id uuid, note text, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), debt_id bigint REFERENCES customer_debts(id),
  title text NOT NULL, body text NOT NULL, scheduled_at timestamptz NOT NULL, delivered_at timestamptz, created_at timestamptz NOT NULL
);
CREATE TABLE IF NOT EXISTS settings (
  owner_user_id uuid NOT NULL REFERENCES owner_users(id), key text NOT NULL, value text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(owner_user_id, key)
);
CREATE TABLE IF NOT EXISTS activity_logs (
  id uuid PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), action text NOT NULL,
  entity_type text NOT NULL, entity_id text, details text, created_at timestamptz NOT NULL
);

-- Immutable, idempotent change log. Financial events are never overwritten.
CREATE TABLE IF NOT EXISTS sync_events (
  server_seq bigserial PRIMARY KEY, event_id uuid NOT NULL UNIQUE, client_id uuid NOT NULL,
  owner_user_id uuid NOT NULL REFERENCES owner_users(id), entity_type text NOT NULL,
  entity_id text NOT NULL, operation text NOT NULL, base_version integer NOT NULL DEFAULT 0,
  payload jsonb NOT NULL, created_at timestamptz NOT NULL, received_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sync_records (
  owner_user_id uuid NOT NULL REFERENCES owner_users(id), entity_type text NOT NULL, entity_id text NOT NULL,
  record_version integer NOT NULL, payload jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(owner_user_id, entity_type, entity_id)
);
CREATE TABLE IF NOT EXISTS sync_conflicts (
  id bigserial PRIMARY KEY, owner_user_id uuid NOT NULL REFERENCES owner_users(id), event_id uuid NOT NULL,
  entity_type text NOT NULL, entity_id text NOT NULL, expected_version integer NOT NULL,
  actual_version integer NOT NULL, payload jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz
);

CREATE INDEX IF NOT EXISTS idx_products_owner_name ON products(owner_user_id, name);
CREATE INDEX IF NOT EXISTS idx_products_owner_barcode ON products(owner_user_id, barcode);
CREATE INDEX IF NOT EXISTS idx_debts_customer_status ON customer_debts(owner_user_id, customer_id, status);
CREATE INDEX IF NOT EXISTS idx_debts_due ON customer_debts(owner_user_id, due_at) WHERE status <> 'PAID';
CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(owner_user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_inventory_product_date ON inventory_transactions(owner_user_id, product_id, created_at);
CREATE INDEX IF NOT EXISTS idx_sync_events_cursor ON sync_events(owner_user_id, server_seq);
CREATE INDEX IF NOT EXISTS idx_sync_events_client ON sync_events(owner_user_id, client_id, server_seq);
