import 'package:flutter/material.dart';

import 'core/database_service.dart';
import 'core/debt_notifications.dart';
import 'screens/auth_screen.dart';
import 'screens/customers_screen.dart';
import 'screens/dashboard_screen.dart';
import 'screens/debts_screen.dart';
import 'screens/more_screen.dart';
import 'screens/pos_screen.dart';
import 'screens/products_screen.dart';

class AppLanguage {
  static final ValueNotifier<bool> english = ValueNotifier<bool>(false);
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DatabaseService.instance.database;
  await DebtNotifications.instance.initialize();
  final db = await DatabaseService.instance.database;
  final settings = await db.query('settings', where: 'key = ?', whereArgs: ['language'], limit: 1);
  if (settings.isNotEmpty) AppLanguage.english.value = settings.first['value'] == 'en';
  runApp(const SuperStoreManagerApp());
}

class SuperStoreManagerApp extends StatelessWidget {
  const SuperStoreManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: AppLanguage.english,
      builder: (context, english, _) => MaterialApp(
        title: 'SUPER STORE MANAGER',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF155E75), brightness: Brightness.light),
          scaffoldBackgroundColor: const Color(0xFFF5F7FA),
          appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FA), surfaceTintColor: Colors.transparent),
          cardTheme: CardThemeData(elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE1E7ED))),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFE1E7ED))),
            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          ),
        ),
        builder: (context, child) => Directionality(
          textDirection: english ? TextDirection.ltr : TextDirection.rtl,
          child: child ?? const SizedBox.shrink(),
        ),
        home: const AppGate(),
      ),
    );
  }
}

class AppGate extends StatefulWidget {
  const AppGate({super.key});

  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> {
  bool _authenticated = false;

  @override
  Widget build(BuildContext context) {
    if (!_authenticated) {
      return AuthScreen(onAuthenticated: () => setState(() => _authenticated = true));
    }
    return AppShell(onLock: () => setState(() => _authenticated = false));
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key, required this.onLock});
  final VoidCallback onLock;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _index = 0;

  @override
  Widget build(BuildContext context) {
    final english = AppLanguage.english.value;
    final pages = const [
      DashboardScreen(),
      ProductsScreen(),
      PosScreen(),
      CustomersScreen(),
      DebtsScreen(),
    ];
    final titles = english
        ? ['Dashboard', 'Products', 'Point of Sale', 'Customers', 'Customer debts']
        : ['عمومي حالت', 'توکي', 'خرڅلاو', 'پېرودونکي', 'د پېرودونکو پورونه'];
    return Scaffold(
      appBar: AppBar(
        title: Text(titles[_index], style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: english ? 'More options' : 'نور امکانات',
            icon: const Icon(Icons.tune_rounded),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MoreScreen(onLock: widget.onLock))),
          ),
        ],
      ),
      body: IndexedStack(index: _index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.space_dashboard_outlined), selectedIcon: const Icon(Icons.space_dashboard), label: english ? 'Home' : 'کور'),
          NavigationDestination(icon: const Icon(Icons.inventory_2_outlined), selectedIcon: const Icon(Icons.inventory_2), label: english ? 'Products' : 'توکي'),
          NavigationDestination(icon: const Icon(Icons.point_of_sale_outlined), selectedIcon: const Icon(Icons.point_of_sale), label: english ? 'Sale' : 'خرڅلاو'),
          NavigationDestination(icon: const Icon(Icons.people_alt_outlined), selectedIcon: const Icon(Icons.people_alt), label: english ? 'Customers' : 'پېرودونکي'),
          NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), selectedIcon: const Icon(Icons.account_balance_wallet), label: english ? 'Debts' : 'پورونه'),
        ],
      ),
    );
  }
}
