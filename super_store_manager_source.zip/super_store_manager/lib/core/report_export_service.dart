import 'dart:io';

import 'package:cross_file/cross_file.dart';
import 'package:excel/excel.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';

import 'business_service.dart';
import 'database_service.dart';

class ReportExportService {
  ReportExportService._();
  static final ReportExportService instance = ReportExportService._();

  String _stamp() => DateFormat('yyyyMMdd-HHmm').format(DateTime.now());

  Future<void> exportExcelWorkbook() async {
    final db = await DatabaseService.instance.database;
    final workbook = Excel.createExcel();
    final products = workbook['Products'];
    products.appendRow([
      TextCellValue('Product'), TextCellValue('Barcode'), TextCellValue('Category'),
      TextCellValue('Purchase price AFN'), TextCellValue('Selling price AFN'),
      TextCellValue('Quantity'), TextCellValue('Minimum stock'), TextCellValue('Expiry date'),
    ]);
    for (final p in await BusinessService.instance.products()) {
      products.appendRow([
        TextCellValue('${p['name'] ?? ''}'), TextCellValue('${p['barcode'] ?? ''}'),
        TextCellValue('${p['category_name'] ?? ''}'), IntCellValue(p['purchase_price'] as int),
        IntCellValue(p['selling_price'] as int), IntCellValue(p['quantity'] as int),
        IntCellValue(p['minimum_quantity'] as int), TextCellValue('${p['expiry_date'] ?? ''}'),
      ]);
    }

    final debts = workbook['Customer Debts'];
    debts.appendRow([
      TextCellValue('Customer'), TextCellValue('Phone'), TextCellValue('Original AFN'),
      TextCellValue('Paid AFN'), TextCellValue('Remaining AFN'), TextCellValue('Due date'), TextCellValue('Status'),
    ]);
    for (final d in await BusinessService.instance.debts()) {
      debts.appendRow([
        TextCellValue('${d['customer_name'] ?? ''}'), TextCellValue('${d['customer_phone'] ?? ''}'),
        IntCellValue(d['original_amount'] as int), IntCellValue(d['paid_amount'] as int),
        IntCellValue(d['remaining'] as int), TextCellValue('${d['due_at'] ?? ''}'), TextCellValue('${d['status'] ?? ''}'),
      ]);
    }

    final sales = workbook['Sales'];
    sales.appendRow([
      TextCellValue('Sale ID'), TextCellValue('Created at'), TextCellValue('Total AFN'),
      TextCellValue('Cash AFN'), TextCellValue('Card AFN'), TextCellValue('Credit AFN'),
    ]);
    final saleRows = await db.query('sales', orderBy: 'created_at DESC', limit: 10000);
    for (final s in saleRows) {
      sales.appendRow([
        TextCellValue('${s['id']}'), TextCellValue('${s['created_at']}'), IntCellValue(s['total_amount'] as int),
        IntCellValue(s['cash_received'] as int), IntCellValue(s['card_received'] as int), IntCellValue(s['credit_amount'] as int),
      ]);
    }

    final expenses = workbook['Expenses'];
    expenses.appendRow([TextCellValue('Title'), TextCellValue('Category'), TextCellValue('Amount AFN'), TextCellValue('Date')]);
    for (final e in await db.query('expenses', orderBy: 'expense_date DESC', limit: 10000)) {
      expenses.appendRow([TextCellValue('${e['title']}'), TextCellValue('${e['category'] ?? ''}'), IntCellValue(e['amount'] as int), TextCellValue('${e['expense_date']}')]);
    }

    final returns = workbook['Sales Returns'];
    returns.appendRow([
      TextCellValue('Return ID'), TextCellValue('Sale ID'), TextCellValue('Product'),
      TextCellValue('Quantity'), TextCellValue('Refund AFN'), TextCellValue('Refund method'),
      TextCellValue('Restocked'), TextCellValue('Reason'), TextCellValue('Date'),
    ]);
    final returnRows = await db.rawQuery('''
      SELECT sr.*, si.product_name FROM sales_returns sr
      JOIN sale_items si ON si.id=sr.sale_item_id
      ORDER BY sr.created_at DESC LIMIT 10000
    ''');
    for (final r in returnRows) {
      returns.appendRow([
        TextCellValue('${r['id']}'), TextCellValue('${r['sale_id']}'), TextCellValue('${r['product_name']}'),
        IntCellValue(r['quantity'] as int), IntCellValue(r['refund_amount'] as int),
        TextCellValue('${r['refund_method'] ?? 'CASH'}'),
        TextCellValue((r['restock'] as int) == 1 ? 'Yes' : 'No'),
        TextCellValue('${r['reason'] ?? ''}'), TextCellValue('${r['created_at']}'),
      ]);
    }

    final purchases = workbook['Purchases'];
    purchases.appendRow([TextCellValue('Invoice'), TextCellValue('Supplier ID'), TextCellValue('Total AFN'), TextCellValue('Paid AFN'), TextCellValue('Balance AFN'), TextCellValue('Date')]);
    for (final p in await db.query('purchases', orderBy: 'purchase_date DESC', limit: 10000)) {
      final total = p['total_amount'] as int;
      final paid = p['amount_paid'] as int;
      purchases.appendRow([TextCellValue('${p['invoice_number'] ?? ''}'), TextCellValue('${p['supplier_id'] ?? ''}'), IntCellValue(total), IntCellValue(paid), IntCellValue(total - paid), TextCellValue('${p['purchase_date']}')]);
    }

    final bytes = workbook.encode();
    if (bytes == null) throw StateError('Excel report could not be generated.');
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/super-store-report-${_stamp()}.xlsx');
    await file.writeAsBytes(bytes, flush: true);
    await SharePlus.instance.share(ShareParams(
      title: 'Super Store Manager Excel report',
      files: [XFile(file.path)],
    ));
  }

  Future<void> exportFinancialPdf() async {
    final m = await BusinessService.instance.dashboardMetrics();
    final pdf = pw.Document();
    final rows = <List<String>>[
      ['Products', '${m['product_count']}'],
      ['Available stock units', '${m['units']}'],
      ['Inventory purchase value', '${m['inventory_cost']} AFN'],
      ['Potential inventory sales value', '${m['inventory_sales']} AFN'],
      ['Potential inventory profit', '${m['inventory_profit']} AFN'],
      ['Sales today', '${m['sales_today']} AFN'],
      ['Sales this month', '${m['sales_month']} AFN'],
      ['Sales this year', '${m['sales_year']} AFN'],
      ['Expenses today', '${m['expense_today']} AFN'],
      ['Expenses this month', '${m['expense_month']} AFN'],
      ['Expenses this year', '${m['expense_year']} AFN'],
      ['Estimated net profit today', '${m['net_profit_today']} AFN'],
      ['Estimated net profit this month', '${m['net_profit_month']} AFN'],
      ['Estimated net profit this year', '${m['net_profit_year']} AFN'],
      ['Refunds today', '${m['refund_today']} AFN'],
      ['Refunds this month', '${m['refund_month']} AFN'],
      ['Refunds this year', '${m['refund_year']} AFN'],
      ['Customer receivables', '${m['customer_debt']} AFN'],
      ['Overdue customer debt', '${m['overdue_debt']} AFN'],
      ['Supplier payables', '${m['supplier_debt']} AFN'],
      ['Cash balance', '${m['cash_balance']} AFN'],
      ['Card receipts balance', '${m['card_balance']} AFN'],
    ];
    pdf.addPage(pw.MultiPage(
      build: (context) => [
        pw.Text('SUPER STORE MANAGER', style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold)),
        pw.SizedBox(height: 5),
        pw.Text('Financial summary • ${DateFormat('yyyy-MM-dd HH:mm').format(DateTime.now())}'),
        pw.SizedBox(height: 18),
        pw.TableHelper.fromTextArray(
          headers: const ['Metric', 'Value'],
          data: rows,
          headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
          cellAlignment: pw.Alignment.centerLeft,
          border: pw.TableBorder.all(color: const PdfColor(0.8, 0.8, 0.8)),
        ),
        pw.SizedBox(height: 14),
        pw.Text('Accounting: credit sales are revenue, not cash received. Inventory purchases are held as stock value and become cost of goods sold when sold.'),
      ],
    ));
    final bytes = await pdf.save();
    await Printing.sharePdf(bytes: bytes, filename: 'super-store-financial-${_stamp()}.pdf');
  }
}
