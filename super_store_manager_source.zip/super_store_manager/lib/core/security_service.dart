import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class SecurityService {
  SecurityService._();
  static final SecurityService instance = SecurityService._();

  static const _storage = FlutterSecureStorage();
  static const _passwordHashKey = 'owner_password_hash_v1';
  static const _passwordSaltKey = 'owner_password_salt_v1';
  static const _databaseKey = 'database_encryption_key_v1';
  static const _apiTokenKey = 'cloud_api_token_v1';

  Future<bool> hasOwnerPassword() async =>
      (await _storage.read(key: _passwordHashKey)) != null;

  Future<String> getOrCreateDatabaseKey() async {
    final existing = await _storage.read(key: _databaseKey);
    if (existing != null && existing.isNotEmpty) return existing;

    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    final key = base64UrlEncode(bytes);
    await _storage.write(key: _databaseKey, value: key);
    return key;
  }

  Future<void> createOwnerPassword(String password) async {
    if (password.length < 10) {
      throw ArgumentError('Password must contain at least 10 characters.');
    }
    final random = Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final derived = await _derive(password, salt);
    await _storage.write(key: _passwordSaltKey, value: base64Encode(salt));
    await _storage.write(
      key: _passwordHashKey,
      value: base64Encode(derived),
    );
  }

  Future<bool> verifyOwnerPassword(String password) async {
    final saltValue = await _storage.read(key: _passwordSaltKey);
    final hashValue = await _storage.read(key: _passwordHashKey);
    if (saltValue == null || hashValue == null) return false;
    final salt = base64Decode(saltValue);
    final expected = base64Decode(hashValue);
    final actual = await _derive(password, salt);
    if (actual.length != expected.length) return false;
    var diff = 0;
    for (var i = 0; i < actual.length; i++) {
      diff |= actual[i] ^ expected[i];
    }
    return diff == 0;
  }

  Future<List<int>> _derive(String password, List<int> salt) async {
    final algorithm = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: 210000,
      bits: 256,
    );
    final key = await algorithm.deriveKey(
      secretKey: SecretKey(utf8.encode(password)),
      nonce: Uint8List.fromList(salt),
    );
    return key.extractBytes();
  }

  Future<void> saveApiToken(String token) =>
      _storage.write(key: _apiTokenKey, value: token);

  Future<String?> readApiToken() => _storage.read(key: _apiTokenKey);

  Future<void> clearApiToken() => _storage.delete(key: _apiTokenKey);
}
