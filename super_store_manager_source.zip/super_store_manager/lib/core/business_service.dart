import 'dart:convert';

import 'package:sqflite_sqlcipher/sqflite.dart';

import 'database_service.dart';
import 'debt_date.dart';
import 'debt_notifications.dart';

class SaleLine {
  const SaleLine({required this.productId, required this.quantity, this.unitCost});
  final String productId;
  final int quantity;
  final int? unitCost;
}


class BusinessService {
  BusinessService._();
  static final BusinessService instance = BusinessService._();
  final _dbService = DatabaseService.instance;

  Future<List<Map<String, Object?>>> products({String search = ''}) async {
    final db = await _dbService.database;
    if (search.trim().isEmpty) {
      return db.query('products', where: 'is_archived = 0', orderBy: 'name COLLATE NOCASE');
    }
    final term = '%${search.trim()}%';
    return db.rawQuery('''
      SELECT * FROM products WHERE is_archived = 0
      AND (name LIKE ? OR barcode LIKE ? OR category_name LIKE ?)
      ORDER BY name COLLATE NOCASE LIMIT 100
    ''', [term, term, term]);
  }

  Future<void> saveProduct({
    String? id,
    required String name,
    String? barcode,
    String? category,
    required int purchasePrice,
    required int sellingPrice,
    required int quantity,
    required int minimumQuantity,
    String? expiryDate,
    String? imagePath,
  }) async {
    if (name.trim().isEmpty) throw ArgumentError('Product name is required.');
    if (purchasePrice < 0 || sellingPrice < 0 || quantity < 0 || minimumQuantity < 0) {
      throw ArgumentError('Price and quantity values cannot be negative.');
    }
    if (sellingPrice < purchasePrice) {
      // Loss-making products are allowed deliberately; the owner decides.
    }
    final db = await _dbService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    final productId = id ?? _dbService.newId();
    await db.transaction((tx) async {
      if (id == null) {
        await tx.insert('products', {
          'id': productId,
          'name': name.trim(),
          'barcode': barcode?.trim().isEmpty == true ? null : barcode?.trim(),
          'category_name': category?.trim(),
          'purchase_price': purchasePrice,
          'selling_price': sellingPrice,
          'quantity': quantity,
          'minimum_quantity': minimumQuantity,
          'expiry_date': expiryDate,
          'image_path': imagePath,
          'created_at': now,
          'updated_at': now,
        });
        if (quantity > 0) {
          await tx.insert('inventory_transactions', {
            'id': _dbService.newId(),
            'product_id': productId,
            'transaction_type': 'OPENING_STOCK',
            'quantity_delta': quantity,
            'unit_cost': purchasePrice,
            'note': 'Opening stock',
            'created_at': now,
          });
        }
        await _dbService.logActivity(tx, 'CREATE', 'PRODUCT', productId, name);
      } else {
        await tx.update('products', {
          'name': name.trim(),
          'barcode': barcode?.trim().isEmpty == true ? null : barcode?.trim(),
          'category_name': category?.trim(),
          'purchase_price': purchasePrice,
          'selling_price': sellingPrice,
          'minimum_quantity': minimumQuantity,
          'expiry_date': expiryDate,
          'image_path': imagePath,
          'updated_at': now,
        }, where: 'id = ?', whereArgs: [productId]);
        // Stock is changed only through inventory transactions, never by editing the product form.
        await tx.rawUpdate('UPDATE products SET version = version + 1 WHERE id = ?', [productId]);
        await _dbService.logActivity(tx, 'UPDATE', 'PRODUCT', productId, name);
      }
      final saved = await tx.query('products', where: 'id = ?', whereArgs: [productId], limit: 1);
      await _dbService.enqueueSync(tx, 'product', productId, id == null ? 'CREATE' : 'UPDATE', jsonEncode(saved.first));
    });
  }

  Future<void> archiveProduct(String productId) async {
    final db = await _dbService.database;
    await db.transaction((tx) async {
      await tx.update('products', {
        'is_archived': 1,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      }, where: 'id = ?', whereArgs: [productId]);
      await _dbService.logActivity(tx, 'ARCHIVE', 'PRODUCT', productId, 'Product archived; historical records retained.');
    });
  }

  Future<void> adjustStock({
    required String productId,
    required int quantityDelta,
    required String reason,
    String? note,
  }) async {
    if (quantityDelta == 0) throw ArgumentError('Stock adjustment cannot be zero.');
    final db = await _dbService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.transaction((tx) async {
      final rows = await tx.query('products', where: 'id=? AND is_archived=0', whereArgs: [productId], limit: 1);
      if (rows.isEmpty) throw StateError('Product not found.');
      final product = rows.first;
      final oldQty = product['quantity'] as int;
      final nextQty = oldQty + quantityDelta;
      if (nextQty < 0) throw ArgumentError('Adjustment would make stock negative.');
      await tx.update('products', {
        'quantity': nextQty,
        'updated_at': now,
        'version': (product['version'] as int) + 1,
      }, where: 'id=?', whereArgs: [productId]);
      final movementId = _dbService.newId();
      await tx.insert('inventory_transactions', {
        'id': movementId,
        'product_id': productId,
        'transaction_type': reason,
        'quantity_delta': quantityDelta,
        'unit_cost': product['purchase_price'],
        'note': note,
        'created_at': now,
      });
      await _dbService.logActivity(tx, 'STOCK_ADJUSTMENT', 'PRODUCT', productId, '$reason: $quantityDelta; ${note ?? ''}');
      await _dbService.enqueueSync(tx, 'inventory_transaction', movementId, 'CREATE', jsonEncode({
        'id': movementId, 'product_id': productId, 'transaction_type': reason,
        'quantity_delta': quantityDelta, 'unit_cost': product['purchase_price'],
        'note': note, 'created_at': now,
      }));
    });
  }

  Future<List<Map<String, Object?>>> inventoryHistory({String? productId, int limit = 100}) async {
    final db = await _dbService.database;
    if (productId != null) {
      return db.rawQuery('''
        SELECT i.*, p.name AS product_name FROM inventory_transactions i
        JOIN products p ON p.id=i.product_id WHERE i.product_id=?
        ORDER BY i.created_at DESC LIMIT ?
      ''', [productId, limit]);
    }
    return db.rawQuery('''
      SELECT i.*, p.name AS product_name FROM inventory_transactions i
      JOIN products p ON p.id=i.product_id ORDER BY i.created_at DESC LIMIT ?
    ''', [limit]);
  }

  Future<List<Map<String, Object?>>> customers({String search = ''}) async {
    final db = await _dbService.database;
    final term = '%${search.trim()}%';
    return db.rawQuery('''
      SELECT c.*,
        COALESCE((SELECT SUM(d.original_amount-d.paid_amount) FROM customer_debts d
          WHERE d.customer_id=c.id AND d.status IN ('OPEN','PARTIAL')),0) AS balance
      FROM customers c WHERE c.is_archived=0 AND (c.name LIKE ? OR c.phone LIKE ?)
      ORDER BY c.name COLLATE NOCASE LIMIT 200
    ''', [term, term]);
  }

  Future<List<Map<String, Object?>>> customerDebtHistory(String customerId) async {
    final db = await _dbService.database;
    return db.rawQuery('''
      SELECT d.*, (d.original_amount-d.paid_amount) AS remaining
      FROM customer_debts d WHERE d.customer_id=?
      ORDER BY d.created_at DESC
    ''', [customerId]);
  }

  Future<void> saveCustomer({String? id, required String name, String? phone, String? address}) async {
    if (name.trim().isEmpty) throw ArgumentError('Customer name is required.');
    final db = await _dbService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    final customerId = id ?? _dbService.newId();
    await db.transaction((tx) async {
      if (id == null) {
        await tx.insert('customers', {
          'id': customerId,
          'name': name.trim(),
          'phone': phone?.trim(),
          'address': address?.trim(),
          'created_at': now,
          'updated_at': now,
        });
        await _dbService.logActivity(tx, 'CREATE', 'CUSTOMER', customerId, name);
      } else {
        await tx.update('customers', {
          'name': name.trim(),
          'phone': phone?.trim(),
          'address': address?.trim(),
          'updated_at': now,
        }, where: 'id = ?', whereArgs: [customerId]);
        await tx.rawUpdate('UPDATE customers SET version = version + 1 WHERE id = ?', [customerId]);
        await _dbService.logActivity(tx, 'UPDATE', 'CUSTOMER', customerId, name);
      }
      final saved = await tx.query('customers', where: 'id = ?', whereArgs: [customerId], limit: 1);
      await _dbService.enqueueSync(tx, 'customer', customerId, id == null ? 'CREATE' : 'UPDATE', jsonEncode(saved.first));
    });
  }

  Future<String> createSale({
    required List<SaleLine> lines,
    String? customerId,
    required int discount,
    required int cashReceived,
    int cardReceived = 0,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Cart is empty.');
    if (discount < 0 || cashReceived < 0 || cardReceived < 0) {
      throw ArgumentError('Amounts cannot be negative.');
    }
    final db = await _dbService.database;
    final nowLocal = DateTime.now();
    final now = nowLocal.toUtc().toIso8601String();
    var createdDebtId = 0;
    var saleIdForReceipt = '';
    await db.transaction((tx) async {
      var subtotal = 0;
      final snapshots = <Map<String, Object?>>[];
      for (final line in lines) {
        if (line.quantity <= 0) throw ArgumentError('Quantity must be greater than zero.');
        final found = await tx.query('products', where: 'id = ? AND is_archived = 0', whereArgs: [line.productId], limit: 1);
        if (found.isEmpty) throw StateError('A product in the cart no longer exists.');
        final product = found.first;
        final stock = product['quantity'] as int;
        if (stock < line.quantity) throw StateError('Not enough stock for ${product['name']}. Available: $stock');
        final unitPrice = product['selling_price'] as int;
        final unitCost = product['purchase_price'] as int;
        subtotal += unitPrice * line.quantity;
        snapshots.add({
          'id': line.productId,
          'name': product['name'],
          'qty': line.quantity,
          'price': unitPrice,
          'cost': unitCost,
          'line': unitPrice * line.quantity,
        });
      }
      if (discount > subtotal) throw ArgumentError('Discount cannot exceed the subtotal.');
      // Allocate the sale-wide discount across lines. The final line absorbs
      // rounding so the sum of line totals always equals the invoice total.
      var grossAllocated = 0;
      var discountAllocated = 0;
      for (var i = 0; i < snapshots.length; i++) {
        final grossLine = snapshots[i]['line'] as int;
        grossAllocated += grossLine;
        final cumulativeDiscount = i == snapshots.length - 1
            ? discount
            : subtotal == 0 ? 0 : (discount * grossAllocated ~/ subtotal);
        final lineDiscount = cumulativeDiscount - discountAllocated;
        snapshots[i]['netLine'] = grossLine - lineDiscount;
        discountAllocated = cumulativeDiscount;
      }
      final total = subtotal - discount;
      final credit = total - cashReceived - cardReceived;
      if (credit < 0) throw ArgumentError('Received amount cannot exceed the sale total.');
      if (credit > 0 && customerId == null) {
        throw StateError('Select a customer for a credit sale.');
      }
      final saleId = _dbService.newId();
      saleIdForReceipt = saleId;
      await tx.insert('sales', {
        'id': saleId,
        'customer_id': customerId,
        'subtotal': subtotal,
        'discount': discount,
        'total_amount': total,
        'cash_received': cashReceived,
        'card_received': cardReceived,
        'credit_amount': credit,
        'created_at': now,
      });
      for (final item in snapshots) {
        final lineId = _dbService.newId();
        final productId = item['id'] as String;
        final qty = item['qty'] as int;
        await tx.insert('sale_items', {
          'id': lineId,
          'sale_id': saleId,
          'product_id': productId,
          'product_name': item['name'],
          'quantity': qty,
          'unit_price': item['price'],
          'unit_cost': item['cost'],
          'line_total': item['netLine'],
        });
        final changed = await tx.rawUpdate(
          'UPDATE products SET quantity = quantity - ?, updated_at = ? WHERE id = ? AND quantity >= ?',
          [qty, now, productId, qty],
        );
        if (changed != 1) throw StateError('Stock changed while processing this sale.');
        await tx.insert('inventory_transactions', {
          'id': _dbService.newId(),
          'product_id': productId,
          'transaction_type': 'SALE',
          'quantity_delta': -qty,
          'unit_cost': item['cost'],
          'reference_type': 'SALE',
          'reference_id': saleId,
          'created_at': now,
        });
      }
      final received = cashReceived + cardReceived;
      if (cashReceived > 0) {
        await tx.insert('financial_transactions', {
          'id': _dbService.newId(),
          'transaction_type': 'SALE_CASH_RECEIPT',
          'direction': 'IN',
          'amount': cashReceived,
          'reference_type': 'SALE',
          'reference_id': saleId,
          'created_at': now,
        });
      }
      if (cardReceived > 0) {
        await tx.insert('financial_transactions', {
          'id': _dbService.newId(),
          'transaction_type': 'SALE_CARD_RECEIPT',
          'direction': 'IN',
          'amount': cardReceived,
          'reference_type': 'SALE',
          'reference_id': saleId,
          'created_at': now,
        });
      }
      if (credit > 0) {
        final dueDate = addOneCalendarMonth(nowLocal);
        createdDebtId = await tx.insert('customer_debts', {
          'public_id': _dbService.newId(),
          'customer_id': customerId,
          'sale_id': saleId,
          'original_amount': credit,
          'paid_amount': 0,
          'due_at': dueDate.toIso8601String(),
          'status': 'OPEN',
          'created_at': now,
          'updated_at': now,
        });
      }
      await _dbService.logActivity(tx, 'CREATE', 'SALE', saleId, 'Total=$total; received=$received; credit=$credit');
      await _dbService.enqueueSync(tx, 'sale', saleId, 'CREATE', jsonEncode({
        'sale': {'id': saleId, 'customer_id': customerId, 'subtotal': subtotal, 'discount': discount, 'total_amount': total, 'cash_received': cashReceived, 'card_received': cardReceived, 'credit_amount': credit, 'created_at': now},
        'items': snapshots,
      }));
      if (createdDebtId > 0) {
        final debt = await tx.query('customer_debts', where: 'id = ?', whereArgs: [createdDebtId], limit: 1);
        await _dbService.enqueueSync(tx, 'customer_debt', debt.first['public_id'] as String, 'CREATE', jsonEncode(debt.first));
      }
    });
    if (createdDebtId > 0) await DebtNotifications.instance.scheduleDebt(createdDebtId);
    return saleIdForReceipt;
  }

  Future<void> recordSalesReturn({
    required String saleId,
    required String saleItemId,
    required int quantity,
    required int refundAmount,
    required bool restock,
    String refundMethod = 'CASH',
    String? reason,
  }) async {
    if (quantity <= 0 || refundAmount < 0) throw ArgumentError('Enter a valid return quantity and refund.');
    if (!['CASH', 'CARD'].contains(refundMethod)) throw ArgumentError('Select a valid refund method.');
    final db = await _dbService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    await db.transaction((tx) async {
      final saleRows = await tx.query('sales', where: 'id=?', whereArgs: [saleId], limit: 1);
      if (saleRows.isEmpty) throw StateError('Sale was not found.');
      if ((saleRows.first['credit_amount'] as int) > 0) {
        throw StateError('Returns against credit sales are not supported yet. Settle or adjust the customer debt separately.');
      }
      final rows = await tx.query('sale_items', where: 'id=? AND sale_id=?', whereArgs: [saleItemId, saleId], limit: 1);
      if (rows.isEmpty) throw StateError('Sale item was not found.');
      final item = rows.first;
      final soldQty = item['quantity'] as int;
      final returnedRows = await tx.rawQuery('''
        SELECT COALESCE(SUM(quantity),0) AS returned,
               COALESCE(SUM(refund_amount),0) AS refunded
        FROM sales_returns WHERE sale_item_id=?
      ''', [saleItemId]);
      final returnedQty = (returnedRows.first['returned'] as num).toInt();
      final priorRefund = (returnedRows.first['refunded'] as num).toInt();
      if (quantity > soldQty - returnedQty) throw ArgumentError('Return quantity exceeds the unreturned sold quantity.');
      // line_total stores the line's net share after invoice discount.
      // Cumulative rounding is calculated against the units returned so far.
      final netLineTotal = item['line_total'] as int;
      final refundCeiling = (netLineTotal * (returnedQty + quantity) ~/ soldQty) - priorRefund;
      if (refundAmount > refundCeiling) throw ArgumentError('Refund exceeds the discounted amount available for these units.');
      final returnId = _dbService.newId();
      await tx.insert('sales_returns', {
        'id': returnId, 'sale_id': saleId, 'sale_item_id': saleItemId,
        'quantity': quantity, 'refund_amount': refundAmount, 'refund_method': refundMethod,
        'restock': restock ? 1 : 0, 'reason': reason, 'created_at': now,
      });
      if (restock) {
        final productId = item['product_id'] as String;
        await tx.rawUpdate('UPDATE products SET quantity=quantity+?, updated_at=?, version=version+1 WHERE id=?', [quantity, now, productId]);
        await tx.insert('inventory_transactions', {
          'id': _dbService.newId(), 'product_id': productId, 'transaction_type': 'SALES_RETURN',
          'quantity_delta': quantity, 'unit_cost': item['unit_cost'],
          'reference_type': 'SALES_RETURN', 'reference_id': returnId,
          'note': reason, 'created_at': now,
        });
      }
      if (refundAmount > 0) {
        await tx.insert('financial_transactions', {
          'id': _dbService.newId(),
          'transaction_type': refundMethod == 'CARD' ? 'SALES_REFUND_CARD' : 'SALES_REFUND',
          'direction': 'OUT',
          'amount': refundAmount, 'reference_type': 'SALES_RETURN', 'reference_id': returnId, 'created_at': now,
        });
      }
      await _dbService.logActivity(tx, 'RETURN', 'SALE', saleId, 'quantity=$quantity; refund=$refundAmount; restock=$restock');
      await _dbService.enqueueSync(tx, 'sales_return', returnId, 'CREATE', jsonEncode({
        'id': returnId, 'sale_id': saleId, 'sale_item_id': saleItemId,
        'quantity': quantity, 'refund_amount': refundAmount, 'refund_method': refundMethod,
        'restock': restock, 'reason': reason, 'created_at': now,
      }));
    });
  }

  Future<List<Map<String, Object?>>> debts({String status = 'ALL'}) async {
    final db = await _dbService.database;
    final statusClause = status == 'ALL' ? '' : 'AND d.status = ?';
    final args = status == 'ALL' ? <Object?>[] : <Object?>[status];
    return db.rawQuery('''
      SELECT d.*, c.name AS customer_name, c.phone AS customer_phone,
        (d.original_amount - d.paid_amount) AS remaining
      FROM customer_debts d JOIN customers c ON c.id = d.customer_id
      WHERE d.status IN ('OPEN','PARTIAL') $statusClause
      ORDER BY d.due_at ASC
    ''', args);
  }

  Future<void> recordDebtPayment({
    required int debtId,
    required int amount,
    String method = 'CASH',
    String? note,
  }) async {
    if (amount <= 0) throw ArgumentError('Payment must be greater than zero.');
    final db = await _dbService.database;
    var shouldCancel = false;
    await db.transaction((tx) async {
      final rows = await tx.query('customer_debts', where: 'id = ?', whereArgs: [debtId], limit: 1);
      if (rows.isEmpty) throw StateError('Debt transaction was not found.');
      final debt = rows.first;
      final original = debt['original_amount'] as int;
      final oldPaid = debt['paid_amount'] as int;
      final remaining = original - oldPaid;
      if (amount > remaining) throw ArgumentError('Payment exceeds the remaining debt of $remaining AFN.');
      final newPaid = oldPaid + amount;
      final complete = newPaid == original;
      final now = DateTime.now().toUtc().toIso8601String();
      final paymentId = _dbService.newId();
      await tx.insert('debt_payments', {
        'id': paymentId,
        'debt_id': debtId,
        'customer_id': debt['customer_id'],
        'amount': amount,
        'payment_method': method,
        'note': note,
        'created_at': now,
      });
      await tx.update('customer_debts', {
        'paid_amount': newPaid,
        'status': complete ? 'PAID' : 'PARTIAL',
        'updated_at': now,
      }, where: 'id = ?', whereArgs: [debtId]);
      await tx.insert('financial_transactions', {
        'id': _dbService.newId(),
        'transaction_type': method == 'CARD' ? 'CUSTOMER_DEBT_CARD_PAYMENT' : 'CUSTOMER_DEBT_PAYMENT',
        'direction': 'IN',
        'amount': amount,
        'reference_type': 'DEBT_PAYMENT',
        'reference_id': paymentId,
        'created_at': now,
      });
      await _dbService.logActivity(tx, 'PAYMENT', 'CUSTOMER_DEBT', debt['public_id'] as String, 'amount=$amount; remaining=${remaining - amount}');
      await _dbService.enqueueSync(tx, 'debt_payment', paymentId, 'CREATE', jsonEncode({
        'debt_public_id': debt['public_id'], 'customer_id': debt['customer_id'], 'amount': amount,
        'method': method, 'created_at': now,
      }));
      shouldCancel = complete;
    });
    if (shouldCancel) {
      await DebtNotifications.instance.cancelDebt(debtId);
    } else {
      // Replaces the scheduled notification with the current remaining balance.
      await DebtNotifications.instance.scheduleDebt(debtId);
    }
  }

  Future<Map<String, int>> debtSummary() async {
    final db = await _dbService.database;
    final total = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL')", []);
    final overdue = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL') AND date(due_at) < date('now','localtime')", []);
    final dueToday = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL') AND date(due_at) = date('now','localtime')", []);
    final dueSeven = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL') AND date(due_at) BETWEEN date('now','localtime') AND date('now','localtime','+7 day')", []);
    final collected = await _sum(db, 'SELECT COALESCE(SUM(amount),0) v FROM debt_payments', []);
    final customersCount = await _sum(db, "SELECT COUNT(DISTINCT customer_id) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL')", []);
    return {'total': total, 'overdue': overdue, 'due_today': dueToday, 'due_seven': dueSeven, 'collected': collected, 'customers': customersCount};
  }

  Future<List<Map<String, Object?>>> debtPayments(int debtId) async {
    final db = await _dbService.database;
    return db.query('debt_payments', where: 'debt_id = ?', whereArgs: [debtId], orderBy: 'created_at DESC');
  }

  Future<Map<String, int>> dashboardMetrics() async {
    final db = await _dbService.database;
    final today = DateTime.now();
    final dayStartLocal = DateTime(today.year, today.month, today.day);
    final tomorrowLocal = DateTime(today.year, today.month, today.day + 1);
    final monthStartLocal = DateTime(today.year, today.month, 1);
    final nextMonthLocal = DateTime(today.year, today.month + 1, 1);
    final yearStartLocal = DateTime(today.year, 1, 1);
    final nextYearLocal = DateTime(today.year + 1, 1, 1);
    final dayStartUtc = dayStartLocal.toUtc().toIso8601String();
    final tomorrowUtc = tomorrowLocal.toUtc().toIso8601String();
    final monthStartUtc = monthStartLocal.toUtc().toIso8601String();
    final nextMonthUtc = nextMonthLocal.toUtc().toIso8601String();
    final yearStartUtc = yearStartLocal.toUtc().toIso8601String();
    final nextYearUtc = nextYearLocal.toUtc().toIso8601String();
    final dayStart = dayStartLocal.toIso8601String();
    final tomorrow = tomorrowLocal.toIso8601String();
    final monthStart = monthStartLocal.toIso8601String();
    final nextMonth = nextMonthLocal.toIso8601String();
    final yearStart = yearStartLocal.toIso8601String();
    final nextYear = nextYearLocal.toIso8601String();
    final p = (await db.rawQuery('''
      SELECT COUNT(*) AS product_count, COALESCE(SUM(quantity),0) AS units,
      COALESCE(SUM(quantity*purchase_price),0) AS inventory_cost,
      COALESCE(SUM(quantity*selling_price),0) AS inventory_sales
      FROM products WHERE is_archived=0
    ''' )).first;
    final grossSalesToday = await _sum(db, 'SELECT COALESCE(SUM(total_amount),0) v FROM sales WHERE created_at >= ? AND created_at < ?', [dayStartUtc, tomorrowUtc]);
    final grossSalesMonth = await _sum(db, 'SELECT COALESCE(SUM(total_amount),0) v FROM sales WHERE created_at >= ? AND created_at < ?', [monthStartUtc, nextMonthUtc]);
    final grossSalesYear = await _sum(db, 'SELECT COALESCE(SUM(total_amount),0) v FROM sales WHERE created_at >= ? AND created_at < ?', [yearStartUtc, nextYearUtc]);
    final refundToday = await _sum(db, 'SELECT COALESCE(SUM(refund_amount),0) v FROM sales_returns WHERE created_at >= ? AND created_at < ?', [dayStartUtc, tomorrowUtc]);
    final refundMonth = await _sum(db, 'SELECT COALESCE(SUM(refund_amount),0) v FROM sales_returns WHERE created_at >= ? AND created_at < ?', [monthStartUtc, nextMonthUtc]);
    final refundYear = await _sum(db, 'SELECT COALESCE(SUM(refund_amount),0) v FROM sales_returns WHERE created_at >= ? AND created_at < ?', [yearStartUtc, nextYearUtc]);
    final salesToday = grossSalesToday - refundToday;
    final salesMonth = grossSalesMonth - refundMonth;
    final salesYear = grossSalesYear - refundYear;
    final expenseToday = await _sum(db, 'SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE expense_date >= ? AND expense_date < ?', [dayStart, tomorrow]);
    final expenseMonth = await _sum(db, 'SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE expense_date >= ? AND expense_date < ?', [monthStart, nextMonth]);
    final expenseYear = await _sum(db, 'SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE expense_date >= ? AND expense_date < ?', [yearStart, nextYear]);
    final cogsToday = await _sum(db, '''SELECT COALESCE(SUM(si.quantity*si.unit_cost),0) v FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.created_at >= ? AND s.created_at < ?''', [dayStartUtc, tomorrowUtc]);
    final cogsMonth = await _sum(db, '''SELECT COALESCE(SUM(si.quantity*si.unit_cost),0) v FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.created_at >= ? AND s.created_at < ?''', [monthStartUtc, nextMonthUtc]);
    final cogsYear = await _sum(db, '''SELECT COALESCE(SUM(si.quantity*si.unit_cost),0) v FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.created_at >= ? AND s.created_at < ?''', [yearStartUtc, nextYearUtc]);
    final returnedCostToday = await _sum(db, '''SELECT COALESCE(SUM(sr.quantity*si.unit_cost),0) v FROM sales_returns sr JOIN sale_items si ON si.id=sr.sale_item_id WHERE sr.restock=1 AND sr.created_at >= ? AND sr.created_at < ?''', [dayStartUtc, tomorrowUtc]);
    final returnedCostMonth = await _sum(db, '''SELECT COALESCE(SUM(sr.quantity*si.unit_cost),0) v FROM sales_returns sr JOIN sale_items si ON si.id=sr.sale_item_id WHERE sr.restock=1 AND sr.created_at >= ? AND sr.created_at < ?''', [monthStartUtc, nextMonthUtc]);
    final returnedCostYear = await _sum(db, '''SELECT COALESCE(SUM(sr.quantity*si.unit_cost),0) v FROM sales_returns sr JOIN sale_items si ON si.id=sr.sale_item_id WHERE sr.restock=1 AND sr.created_at >= ? AND sr.created_at < ?''', [yearStartUtc, nextYearUtc]);
    final debt = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL')", []);
    final overdue = await _sum(db, "SELECT COALESCE(SUM(original_amount-paid_amount),0) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL') AND date(due_at) < date('now','localtime')", []);
    final supplierDebt = await _sum(db, 'SELECT COALESCE(SUM(total_amount-amount_paid),0) v FROM purchases', []);
    final cash = await _sum(db, "SELECT COALESCE(SUM(CASE direction WHEN 'IN' THEN amount ELSE -amount END),0) v FROM financial_transactions WHERE transaction_type NOT IN ('SALE_CARD_RECEIPT','CUSTOMER_DEBT_CARD_PAYMENT','SALES_REFUND_CARD')", []);
    final cardBalance = await _sum(db, "SELECT COALESCE(SUM(CASE direction WHEN 'IN' THEN amount ELSE -amount END),0) v FROM financial_transactions WHERE transaction_type IN ('SALE_CARD_RECEIPT','CUSTOMER_DEBT_CARD_PAYMENT','SALES_REFUND_CARD')", []);
    final lowStock = await _sum(db, 'SELECT COUNT(*) v FROM products WHERE is_archived=0 AND quantity <= minimum_quantity', []);
    final expired = await _sum(db, "SELECT COUNT(*) v FROM products WHERE is_archived=0 AND expiry_date IS NOT NULL AND date(expiry_date) < date('now','localtime')", []);
    final expiring = await _sum(db, "SELECT COUNT(*) v FROM products WHERE is_archived=0 AND expiry_date IS NOT NULL AND date(expiry_date) BETWEEN date('now','localtime') AND date('now','localtime','+30 day')", []);
    final debtCount = await _sum(db, "SELECT COUNT(*) v FROM customer_debts WHERE status IN ('OPEN','PARTIAL')", []);
    final adjustedCogsToday = cogsToday - returnedCostToday;
    final adjustedCogsMonth = cogsMonth - returnedCostMonth;
    final adjustedCogsYear = cogsYear - returnedCostYear;
    final todayGrossProfit = salesToday - adjustedCogsToday;
    return {
      'product_count': p['product_count'] as int,
      'units': p['units'] as int,
      'inventory_cost': p['inventory_cost'] as int,
      'inventory_sales': p['inventory_sales'] as int,
      'inventory_profit': (p['inventory_sales'] as int) - (p['inventory_cost'] as int),
      'sales_today': salesToday,
      'sales_month': salesMonth,
      'sales_year': salesYear,
      'expense_today': expenseToday,
      'expense_month': expenseMonth,
      'expense_year': expenseYear,
      'cogs_today': adjustedCogsToday,
      'refund_today': refundToday,
      'refund_month': refundMonth,
      'refund_year': refundYear,
      'net_profit_today': todayGrossProfit - expenseToday,
      'net_profit_month': salesMonth - adjustedCogsMonth - expenseMonth,
      'net_profit_year': salesYear - adjustedCogsYear - expenseYear,
      'customer_debt': debt,
      'overdue_debt': overdue,
      'supplier_debt': supplierDebt,
      'cash_balance': cash,
      'card_balance': cardBalance,
      'low_stock': lowStock,
      'expired': expired,
      'expiring': expiring,
      'debt_count': debtCount,
    };
  }

  Future<int> _sum(Database db, String sql, List<Object?> args) async {
    final rows = await db.rawQuery(sql, args);
    return (rows.first['v'] as num).toInt();
  }


  Future<List<Map<String, Object?>>> suppliers() async {
    final db = await _dbService.database;
    return db.rawQuery('''
      SELECT s.*,
        COALESCE((SELECT SUM(p.total_amount-p.amount_paid) FROM purchases p WHERE p.supplier_id=s.id),0) AS balance
      FROM suppliers s WHERE s.is_archived=0 ORDER BY s.name COLLATE NOCASE
    ''');
  }

  Future<void> saveSupplier({String? id, required String name, String? phone, String? address}) async {
    if (name.trim().isEmpty) throw ArgumentError('Supplier name is required.');
    final db = await _dbService.database;
    final now = DateTime.now().toUtc().toIso8601String();
    final supplierId = id ?? _dbService.newId();
    await db.transaction((tx) async {
      if (id == null) {
        await tx.insert('suppliers', {'id': supplierId, 'name': name.trim(), 'phone': phone?.trim(), 'address': address?.trim(), 'created_at': now, 'updated_at': now});
      } else {
        await tx.update('suppliers', {'name': name.trim(), 'phone': phone?.trim(), 'address': address?.trim(), 'updated_at': now}, where: 'id=?', whereArgs: [supplierId]);
      }
      await _dbService.logActivity(tx, id == null ? 'CREATE' : 'UPDATE', 'SUPPLIER', supplierId, name);
    });
  }

  Future<void> recordPurchase({
    String? supplierId,
    required List<SaleLine> lines,
    required int amountPaid,
    String? invoiceNumber,
    String? note,
  }) async {
    if (lines.isEmpty) throw ArgumentError('Purchase has no items.');
    if (amountPaid < 0) throw ArgumentError('Paid amount cannot be negative.');
    final db = await _dbService.database;
    final nowLocal = DateTime.now();
    final now = nowLocal.toUtc().toIso8601String();
    await db.transaction((tx) async {
      var total = 0;
      final items = <Map<String, Object?>>[];
      for (final line in lines) {
        if (line.quantity <= 0) throw ArgumentError('Quantity must be positive.');
        final rows = await tx.query('products', where: 'id=? AND is_archived=0', whereArgs: [line.productId], limit: 1);
        if (rows.isEmpty) throw StateError('Purchase product not found.');
        final product = rows.first;
        final unitCost = line.unitCost ?? (product['purchase_price'] as int);
        if (unitCost < 0) throw ArgumentError('Purchase cost cannot be negative.');
        total += unitCost * line.quantity;
        items.add({'product': product, 'qty': line.quantity, 'cost': unitCost, 'line': unitCost * line.quantity});
      }
      if (amountPaid > total) throw ArgumentError('Paid amount cannot exceed the purchase total.');
      final purchaseId = _dbService.newId();
      await tx.insert('purchases', {
        'id': purchaseId, 'supplier_id': supplierId, 'invoice_number': invoiceNumber,
        'total_amount': total, 'amount_paid': amountPaid, 'purchase_date': nowLocal.toIso8601String(),
        'note': note, 'created_at': now,
      });
      for (final item in items) {
        final product = item['product'] as Map<String, Object?>;
        final productId = product['id'] as String;
        final qty = item['qty'] as int;
        await tx.insert('purchase_items', {
          'id': _dbService.newId(), 'purchase_id': purchaseId, 'product_id': productId,
          'quantity': qty, 'unit_cost': item['cost'], 'line_total': item['line'],
        });
        final oldQty = product['quantity'] as int;
        final oldCost = product['purchase_price'] as int;
        final weightedCost = oldQty + qty == 0 ? (item['cost'] as int) : ((oldQty * oldCost) + (qty * (item['cost'] as int))) ~/ (oldQty + qty);
        await tx.rawUpdate('UPDATE products SET quantity=quantity+?, purchase_price=?, updated_at=?, version=version+1 WHERE id=?', [qty, weightedCost, now, productId]);
        await tx.insert('inventory_transactions', {
          'id': _dbService.newId(), 'product_id': productId, 'transaction_type': 'PURCHASE',
          'quantity_delta': qty, 'unit_cost': item['cost'], 'reference_type': 'PURCHASE',
          'reference_id': purchaseId, 'created_at': now,
        });
      }
      if (amountPaid > 0) {
        await tx.insert('financial_transactions', {
          'id': _dbService.newId(), 'transaction_type': 'PURCHASE_PAYMENT', 'direction': 'OUT',
          'amount': amountPaid, 'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'created_at': now,
        });
      }
      await _dbService.logActivity(tx, 'CREATE', 'PURCHASE', purchaseId, 'total=$total; paid=$amountPaid');
      await _dbService.enqueueSync(tx, 'purchase', purchaseId, 'CREATE', jsonEncode({'id': purchaseId, 'total': total, 'amount_paid': amountPaid, 'supplier_id': supplierId, 'created_at': now}));
    });
  }

  Future<void> paySupplierInvoice({required String purchaseId, required int amount}) async {
    if (amount <= 0) throw ArgumentError('Payment must be positive.');
    final db = await _dbService.database;
    await db.transaction((tx) async {
      final rows = await tx.query('purchases', where: 'id=?', whereArgs: [purchaseId], limit: 1);
      if (rows.isEmpty) throw StateError('Purchase invoice not found.');
      final purchase = rows.first;
      final remaining = (purchase['total_amount'] as int) - (purchase['amount_paid'] as int);
      if (amount > remaining) throw ArgumentError('Payment exceeds supplier balance.');
      await tx.rawUpdate('UPDATE purchases SET amount_paid=amount_paid+? WHERE id=?', [amount, purchaseId]);
      final now = DateTime.now().toUtc().toIso8601String();
      await tx.insert('financial_transactions', {
        'id': _dbService.newId(), 'transaction_type': 'SUPPLIER_PAYMENT', 'direction': 'OUT',
        'amount': amount, 'reference_type': 'PURCHASE', 'reference_id': purchaseId, 'created_at': now,
      });
      await _dbService.logActivity(tx, 'PAYMENT', 'SUPPLIER_INVOICE', purchaseId, '$amount AFN');
    });
  }

  Future<void> addExpense({required String title, required int amount, String? category, String? note}) async {
    if (title.trim().isEmpty || amount <= 0) throw ArgumentError('Enter an expense title and a positive amount.');
    final db = await _dbService.database;
    final now = DateTime.now();
    final nowIso = now.toUtc().toIso8601String();
    final expenseId = _dbService.newId();
    await db.transaction((tx) async {
      await tx.insert('expenses', {
        'id': expenseId, 'title': title.trim(), 'category': category,
        'amount': amount, 'note': note, 'expense_date': now.toIso8601String(), 'created_at': nowIso,
      });
      await tx.insert('financial_transactions', {
        'id': _dbService.newId(), 'transaction_type': 'EXPENSE', 'direction': 'OUT',
        'amount': amount, 'reference_type': 'EXPENSE', 'reference_id': expenseId, 'created_at': nowIso,
      });
      await _dbService.logActivity(tx, 'CREATE', 'EXPENSE', expenseId, '$title: $amount AFN');
      await _dbService.enqueueSync(tx, 'expense', expenseId, 'CREATE', jsonEncode({'id': expenseId, 'title': title.trim(), 'category': category, 'amount': amount, 'expense_date': now.toIso8601String(), 'created_at': nowIso}));
    });
  }
}
