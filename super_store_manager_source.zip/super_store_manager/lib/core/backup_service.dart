import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';
import 'package:cross_file/cross_file.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

import 'database_service.dart';
import 'debt_notifications.dart';

class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();

  static const _tables = <String>[
    'users', 'categories', 'products', 'customers', 'suppliers', 'sales',
    'sale_items', 'customer_debts', 'debt_payments', 'purchases', 'purchase_items',
    'inventory_transactions', 'sales_returns', 'expenses', 'financial_transactions',
    'notifications', 'settings', 'activity_logs', 'sync_queue',
  ];

  Future<void> createEncryptedBackup(String backupPassword) async {
    if (backupPassword.length < 10) {
      throw ArgumentError('Backup password must contain at least 10 characters.');
    }
    final db = await DatabaseService.instance.database;
    final tables = <String, List<Map<String, Object?>>>{};
    for (final table in _tables) {
      tables[table] = await db.query(table);
    }
    final clearText = utf8.encode(jsonEncode({
      'format': 'SUPER_STORE_MANAGER_BACKUP',
      'version': 1,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'tables': tables,
    }));
    final random = Random.secure();
    final salt = List<int>.generate(16, (_) => random.nextInt(256));
    final nonce = List<int>.generate(12, (_) => random.nextInt(256));
    final key = await _deriveKey(backupPassword, salt);
    final box = await AesGcm.with256bits().encrypt(
      clearText,
      secretKey: SecretKey(key),
      nonce: nonce,
    );
    final envelope = {
      'format': 'SSM-ENCRYPTED-BACKUP',
      'version': 1,
      'kdf': 'PBKDF2-HMAC-SHA256-210000',
      'cipher': 'AES-256-GCM',
      'salt': base64Encode(salt),
      'nonce': base64Encode(nonce),
      'ciphertext': base64Encode(box.cipherText),
      'mac': base64Encode(box.mac.bytes),
    };
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/super-store-backup-${DateTime.now().millisecondsSinceEpoch}.ssmbackup');
    await file.writeAsString(jsonEncode(envelope), flush: true);
    await SharePlus.instance.share(ShareParams(
      title: 'Super Store Manager encrypted backup',
      text: 'Keep this backup file and its separate password in a safe place.',
      files: [XFile(file.path)],
    ));
  }

  Future<void> restoreEncryptedBackup(String backupPassword) async {
    final picked = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['ssmbackup'],
    );
    if (picked == null || picked.files.isEmpty) return;
    final path = picked.files.first.path;
    if (path == null) throw StateError('Selected backup file is not accessible.');
    final envelope = jsonDecode(await File(path).readAsString()) as Map<String, dynamic>;
    if (envelope['format'] != 'SSM-ENCRYPTED-BACKUP' || envelope['version'] != 1) {
      throw FormatException('This is not a supported Super Store Manager backup.');
    }
    final salt = base64Decode(envelope['salt'] as String);
    final nonce = base64Decode(envelope['nonce'] as String);
    final cipherText = base64Decode(envelope['ciphertext'] as String);
    final mac = Mac(base64Decode(envelope['mac'] as String));
    final key = await _deriveKey(backupPassword, salt);
    final clearText = await AesGcm.with256bits().decrypt(
      SecretBox(cipherText, nonce: nonce, mac: mac),
      secretKey: SecretKey(key),
    );
    final decoded = jsonDecode(utf8.decode(clearText)) as Map<String, dynamic>;
    if (decoded['format'] != 'SUPER_STORE_MANAGER_BACKUP' || decoded['version'] != 1) {
      throw FormatException('Backup content is invalid or unsupported.');
    }
    final tables = decoded['tables'] as Map<String, dynamic>;
    for (final table in _tables) {
      if (tables[table] is! List) throw FormatException('Backup is missing table $table.');
    }
    final db = await DatabaseService.instance.database;
    await db.transaction((tx) async {
      const deleteOrder = [
        'notifications', 'debt_payments', 'customer_debts', 'sales_returns', 'sale_items',
        'purchase_items', 'inventory_transactions', 'purchases', 'sales',
        'products', 'categories', 'customers', 'suppliers', 'expenses',
        'financial_transactions', 'activity_logs', 'sync_queue',
        'settings', 'users',
      ];
      for (final table in deleteOrder) {
        await tx.delete(table);
      }
      for (final table in _tables) {
        final rows = (tables[table] as List).cast<Map<String, dynamic>>();
        for (final row in rows) {
          await tx.insert(table, Map<String, Object?>.from(row), conflictAlgorithm: ConflictAlgorithm.replace);
        }
      }
      await tx.update('customer_debts', {'reminder_scheduled_at': null}, where: "status IN ('OPEN','PARTIAL')");
    });
    await DebtNotifications.instance.scheduleMissingReminders();
  }

  Future<List<int>> _deriveKey(String password, List<int> salt) async {
    final algorithm = Pbkdf2(macAlgorithm: Hmac.sha256(), iterations: 210000, bits: 256);
    final key = await algorithm.deriveKey(secretKey: SecretKey(utf8.encode(password)), nonce: Uint8List.fromList(salt));
    return key.extractBytes();
  }
}
