import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'database_service.dart';

class DebtNotifications {
  DebtNotifications._();
  static final DebtNotifications instance = DebtNotifications._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;

  // Afghanistan is the default store timezone. Change this to the store's IANA
  // timezone if the supermarket is located elsewhere.
  static const String defaultStoreTimeZone = 'Asia/Kabul';

  Future<void> initialize() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    tz.setLocalLocation(tz.getLocation(defaultStoreTimeZone));
    const settings = InitializationSettings(
      android: AndroidInitializationSettings('ic_stat_notify'),
    );
    await _plugin.initialize(settings);
    final android = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await android?.requestNotificationsPermission();
    final canExact = await android?.canScheduleExactNotifications() ?? false;
    if (!canExact) await android?.requestExactAlarmsPermission();
    _ready = true;
    await scheduleMissingReminders();
  }

  Future<void> scheduleMissingReminders() async {
    final db = await DatabaseService.instance.database;
    final rows = await db.rawQuery('''
      SELECT id FROM customer_debts
      WHERE status IN ('OPEN','PARTIAL') AND reminder_scheduled_at IS NULL
    ''');
    for (final row in rows) {
      await scheduleDebt(row['id'] as int);
    }
  }

  Future<void> scheduleDebt(int debtId) async {
    if (!_ready) await initialize();
    final db = await DatabaseService.instance.database;
    final rows = await db.rawQuery('''
      SELECT d.*, c.name AS customer_name, c.phone AS customer_phone
      FROM customer_debts d JOIN customers c ON c.id = d.customer_id
      WHERE d.id = ? LIMIT 1
    ''', [debtId]);
    if (rows.isEmpty) return;
    final debt = rows.first;
    final original = debt['original_amount'] as int;
    final paid = debt['paid_amount'] as int;
    final balance = original - paid;
    if (balance <= 0 || debt['status'] == 'PAID') {
      await cancelDebt(debtId);
      return;
    }

    final due = DateTime.parse(debt['due_at'] as String);
    final location = tz.getLocation(defaultStoreTimeZone);
    final nowAtStore = tz.TZDateTime.now(location);
    var zonedDate = tz.TZDateTime(location, due.year, due.month, due.day, 9);
    if (!zonedDate.isAfter(nowAtStore)) {
      final tomorrow = nowAtStore.add(const Duration(days: 1));
      zonedDate = tz.TZDateTime(location, tomorrow.year, tomorrow.month, tomorrow.day, 9);
    }
    final customerName = debt['customer_name'] as String;
    final phone = (debt['customer_phone'] as String?)?.trim();
    final dueLabel = DateFormat('dd MMM yyyy').format(due);
    final creditDate = DateFormat('dd MMM yyyy')
        .format(DateTime.parse(debt['created_at'] as String));
    final body = 'Customer: $customerName\nPhone: ${phone?.isNotEmpty == true ? phone : '—'}\n'
        'Original debt: $original AFN\nPaid: $paid AFN\nRemaining: $balance AFN\n'
        'Credit date: $creditDate\nDue date: $dueLabel';
    final details = NotificationDetails(
      android: AndroidNotificationDetails(
        'debt_due_reminders',
        'Customer debt reminders',
        channelDescription: 'One-month reminders for customer credit transactions',
        importance: Importance.max,
        priority: Priority.high,
        category: AndroidNotificationCategory.reminder,
        styleInformation: BigTextStyleInformation(body),
      ),
    );
    await _plugin.zonedSchedule(
      debtId,
      'Payment due: $customerName',
      body,
      zonedDate,
      details,
      androidScheduleMode: (await _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.canScheduleExactNotifications() ?? false)
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      payload: debtId.toString(),
    );
    await db.update(
      'customer_debts',
      {
        'reminder_scheduled_at': DateTime.now().toUtc().toIso8601String(),
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [debtId],
    );
    await db.insert('notifications', {
      'id': DatabaseService.instance.newId(),
      'debt_id': debtId,
      'title': 'Payment due: $customerName',
      'body': body,
      'scheduled_at': zonedDate.toIso8601String(),
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<void> cancelDebt(int debtId) async {
    await _plugin.cancel(debtId);
    final db = await DatabaseService.instance.database;
    await db.update(
      'customer_debts',
      {'reminder_scheduled_at': null, 'updated_at': DateTime.now().toUtc().toIso8601String()},
      where: 'id = ?',
      whereArgs: [debtId],
    );
  }
}
