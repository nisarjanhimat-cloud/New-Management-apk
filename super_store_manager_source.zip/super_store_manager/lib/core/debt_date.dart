/// Adds one calendar month while preserving the time of day.
/// If the target month is shorter, the day is clamped to its final valid day.
DateTime addOneCalendarMonth(DateTime date) {
  final nextMonth = date.month == 12 ? 1 : date.month + 1;
  final nextYear = date.year + (date.month == 12 ? 1 : 0);
  final lastDay = DateTime(nextYear, nextMonth + 1, 0).day;
  return DateTime(
    nextYear,
    nextMonth,
    date.day > lastDay ? lastDay : date.day,
    date.hour,
    date.minute,
    date.second,
    date.millisecond,
    date.microsecond,
  );
}
