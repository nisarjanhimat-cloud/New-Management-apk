import 'package:path/path.dart' as p;
import 'package:sqflite_sqlcipher/sqflite.dart';
import 'package:uuid/uuid.dart';

import 'security_service.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _database;
  final _uuid = const Uuid();

  Future<Database> get database async {
    if (_database != null) return _database!;
    final key = await SecurityService.instance.getOrCreateDatabaseKey();
    final root = await getDatabasesPath();
    final path = p.join(root, 'super_store_manager.db');
    _database = await openDatabase(
      path,
      password: key,
      version: 1,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
        await db.execute('PRAGMA journal_mode = WAL');
        await db.execute('PRAGMA secure_delete = ON');
      },
      onCreate: _createSchema,
    );
    return _database!;
  }

  String newId() => _uuid.v4();

  Future<void> _createSchema(Database db, int version) async {
    final statements = <String>[
      '''CREATE TABLE users (
        id TEXT PRIMARY KEY, display_name TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'owner',
        created_at TEXT NOT NULL)''',
      '''CREATE TABLE categories (
        id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL)''',
      '''CREATE TABLE products (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, barcode TEXT UNIQUE, category_id TEXT,
        category_name TEXT, purchase_price INTEGER NOT NULL CHECK(purchase_price >= 0),
        selling_price INTEGER NOT NULL CHECK(selling_price >= 0),
        quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity >= 0),
        minimum_quantity INTEGER NOT NULL DEFAULT 0 CHECK(minimum_quantity >= 0),
        expiry_date TEXT, image_path TEXT, is_archived INTEGER NOT NULL DEFAULT 0,
        version INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        FOREIGN KEY(category_id) REFERENCES categories(id))''',
      '''CREATE TABLE inventory_transactions (
        id TEXT PRIMARY KEY, product_id TEXT NOT NULL, transaction_type TEXT NOT NULL,
        quantity_delta INTEGER NOT NULL, unit_cost INTEGER NOT NULL DEFAULT 0,
        reference_type TEXT, reference_id TEXT, note TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(product_id) REFERENCES products(id))''',
      '''CREATE TABLE customers (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, address TEXT,
        is_archived INTEGER NOT NULL DEFAULT 0, version INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''',
      '''CREATE TABLE customer_debts (
        id INTEGER PRIMARY KEY AUTOINCREMENT, public_id TEXT NOT NULL UNIQUE,
        customer_id TEXT NOT NULL, sale_id TEXT, original_amount INTEGER NOT NULL CHECK(original_amount > 0),
        paid_amount INTEGER NOT NULL DEFAULT 0 CHECK(paid_amount >= 0),
        due_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'OPEN',
        reminder_scheduled_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
        CHECK(paid_amount <= original_amount),
        FOREIGN KEY(customer_id) REFERENCES customers(id),
        FOREIGN KEY(sale_id) REFERENCES sales(id))''',
      '''CREATE TABLE debt_payments (
        id TEXT PRIMARY KEY, debt_id INTEGER NOT NULL, customer_id TEXT NOT NULL,
        amount INTEGER NOT NULL CHECK(amount > 0), payment_method TEXT NOT NULL DEFAULT 'CASH',
        note TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(debt_id) REFERENCES customer_debts(id),
        FOREIGN KEY(customer_id) REFERENCES customers(id))''',
      '''CREATE TABLE suppliers (
        id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT, address TEXT,
        is_archived INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL, updated_at TEXT NOT NULL)''',
      '''CREATE TABLE purchases (
        id TEXT PRIMARY KEY, supplier_id TEXT, invoice_number TEXT,
        total_amount INTEGER NOT NULL CHECK(total_amount >= 0),
        amount_paid INTEGER NOT NULL DEFAULT 0 CHECK(amount_paid >= 0),
        purchase_date TEXT NOT NULL, note TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(supplier_id) REFERENCES suppliers(id),
        CHECK(amount_paid <= total_amount))''',
      '''CREATE TABLE purchase_items (
        id TEXT PRIMARY KEY, purchase_id TEXT NOT NULL, product_id TEXT NOT NULL,
        quantity INTEGER NOT NULL CHECK(quantity > 0), unit_cost INTEGER NOT NULL CHECK(unit_cost >= 0),
        line_total INTEGER NOT NULL CHECK(line_total >= 0),
        FOREIGN KEY(purchase_id) REFERENCES purchases(id),
        FOREIGN KEY(product_id) REFERENCES products(id))''',
      '''CREATE TABLE sales (
        id TEXT PRIMARY KEY, customer_id TEXT, subtotal INTEGER NOT NULL CHECK(subtotal >= 0),
        discount INTEGER NOT NULL DEFAULT 0 CHECK(discount >= 0),
        total_amount INTEGER NOT NULL CHECK(total_amount >= 0),
        cash_received INTEGER NOT NULL DEFAULT 0 CHECK(cash_received >= 0),
        card_received INTEGER NOT NULL DEFAULT 0 CHECK(card_received >= 0),
        credit_amount INTEGER NOT NULL DEFAULT 0 CHECK(credit_amount >= 0),
        status TEXT NOT NULL DEFAULT 'COMPLETED', created_at TEXT NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id))''',
      '''CREATE TABLE sale_items (
        id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, product_id TEXT NOT NULL,
        product_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity > 0),
        unit_price INTEGER NOT NULL CHECK(unit_price >= 0),
        unit_cost INTEGER NOT NULL CHECK(unit_cost >= 0),
        line_total INTEGER NOT NULL CHECK(line_total >= 0),
        FOREIGN KEY(sale_id) REFERENCES sales(id),
        FOREIGN KEY(product_id) REFERENCES products(id))''',
      '''CREATE TABLE sales_returns (
        id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, sale_item_id TEXT NOT NULL,
        quantity INTEGER NOT NULL CHECK(quantity > 0), refund_amount INTEGER NOT NULL CHECK(refund_amount >= 0),
        refund_method TEXT NOT NULL DEFAULT 'CASH' CHECK(refund_method IN ('CASH','CARD')),
        restock INTEGER NOT NULL DEFAULT 1, reason TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(sale_id) REFERENCES sales(id), FOREIGN KEY(sale_item_id) REFERENCES sale_items(id))''',
      '''CREATE TABLE expenses (
        id TEXT PRIMARY KEY, title TEXT NOT NULL, category TEXT, amount INTEGER NOT NULL CHECK(amount > 0),
        note TEXT, expense_date TEXT NOT NULL, created_at TEXT NOT NULL)''',
      '''CREATE TABLE financial_transactions (
        id TEXT PRIMARY KEY, transaction_type TEXT NOT NULL,
        direction TEXT NOT NULL CHECK(direction IN ('IN','OUT')),
        amount INTEGER NOT NULL CHECK(amount > 0), reference_type TEXT, reference_id TEXT,
        note TEXT, created_at TEXT NOT NULL)''',
      '''CREATE TABLE notifications (
        id TEXT PRIMARY KEY, debt_id INTEGER, title TEXT NOT NULL, body TEXT NOT NULL,
        scheduled_at TEXT NOT NULL, delivered_at TEXT, created_at TEXT NOT NULL,
        FOREIGN KEY(debt_id) REFERENCES customer_debts(id))''',
      '''CREATE TABLE settings (
        key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)''',
      '''CREATE TABLE activity_logs (
        id TEXT PRIMARY KEY, action TEXT NOT NULL, entity_type TEXT NOT NULL,
        entity_id TEXT, details TEXT, created_at TEXT NOT NULL)''',
      '''CREATE TABLE sync_queue (
        id TEXT PRIMARY KEY, entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
        operation TEXT NOT NULL, payload_json TEXT NOT NULL, base_version INTEGER NOT NULL DEFAULT 0,
        attempts INTEGER NOT NULL DEFAULT 0, last_error TEXT, created_at TEXT NOT NULL,
        synced_at TEXT)''',
      'CREATE INDEX idx_products_name ON products(name)',
      'CREATE INDEX idx_products_barcode ON products(barcode)',
      'CREATE INDEX idx_inventory_product_date ON inventory_transactions(product_id, created_at)',
      'CREATE INDEX idx_debts_customer_status ON customer_debts(customer_id, status)',
      'CREATE INDEX idx_debts_due_status ON customer_debts(due_at, status)',
      'CREATE INDEX idx_debt_payments_debt ON debt_payments(debt_id, created_at)',
      'CREATE INDEX idx_sales_created ON sales(created_at)',
      'CREATE INDEX idx_financial_created ON financial_transactions(created_at)',
      'CREATE INDEX idx_sync_pending ON sync_queue(synced_at, created_at)',
    ];
    for (final sql in statements) {
      await db.execute(sql);
    }
  }

  Future<void> logActivity(
    DatabaseExecutor tx,
    String action,
    String entityType,
    String? entityId,
    String? details,
  ) async {
    await tx.insert('activity_logs', {
      'id': newId(),
      'action': action,
      'entity_type': entityType,
      'entity_id': entityId,
      'details': details,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<void> enqueueSync(
    DatabaseExecutor tx,
    String entityType,
    String entityId,
    String operation,
    String payloadJson,
    {int baseVersion = 0},
  ) async {
    await tx.insert('sync_queue', {
      'id': newId(),
      'entity_type': entityType,
      'entity_id': entityId,
      'operation': operation,
      'payload_json': payloadJson,
      'base_version': baseVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
    });
  }
}
