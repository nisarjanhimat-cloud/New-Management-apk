import 'package:flutter/material.dart';

import '../core/security_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key, required this.onAuthenticated});
  final VoidCallback onAuthenticated;

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  bool _setup = false;
  bool _loading = true;
  bool _busy = false;
  bool _showPassword = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _checkSetup();
  }

  Future<void> _checkSetup() async {
    final hasPassword = await SecurityService.instance.hasOwnerPassword();
    if (!mounted) return;
    setState(() {
      _setup = !hasPassword;
      _loading = false;
    });
  }

  Future<void> _submit() async {
    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (_setup) {
        if (_password.text != _confirm.text) {
          throw ArgumentError('Passwords do not match.');
        }
        await SecurityService.instance.createOwnerPassword(_password.text);
      } else {
        final ok = await SecurityService.instance.verifyOwnerPassword(_password.text);
        if (!ok) throw ArgumentError('Incorrect password.');
      }
      widget.onAuthenticated();
    } catch (e) {
      if (mounted) setState(() => _error = e.toString().replaceFirst('ArgumentError: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 78,
                  width: 78,
                  decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(24)),
                  child: Icon(Icons.storefront_rounded, size: 42, color: Theme.of(context).colorScheme.primary),
                ),
                const SizedBox(height: 20),
                Text('SUPER STORE MANAGER', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 8),
                Text(_setup ? 'د مالک پټنوم جوړ کړئ' : 'د مالک حساب ته ننوتل', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 28),
                TextField(
                  controller: _password,
                  obscureText: !_showPassword,
                  decoration: InputDecoration(
                    labelText: _setup ? 'New password' : 'Owner password',
                    prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      onPressed: () => setState(() => _showPassword = !_showPassword),
                      icon: Icon(_showPassword ? Icons.visibility_off : Icons.visibility),
                    ),
                  ),
                  onSubmitted: (_) => _setup ? null : _submit(),
                ),
                if (_setup) ...[
                  const SizedBox(height: 14),
                  TextField(
                    controller: _confirm,
                    obscureText: !_showPassword,
                    decoration: const InputDecoration(labelText: 'Confirm password', prefixIcon: Icon(Icons.verified_user_outlined)),
                  ),
                  const SizedBox(height: 8),
                  const Text('Use at least 10 characters. The password is never stored as plain text.', textAlign: TextAlign.center),
                ],
                if (_error != null) ...[
                  const SizedBox(height: 14),
                  Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                ],
                const SizedBox(height: 22),
                SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy ? const CircularProgressIndicator() : Text(_setup ? 'Create owner account' : 'Unlock application'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
