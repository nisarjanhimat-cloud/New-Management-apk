import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/business_service.dart';
import '../main.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});

  @override
  State<CustomersScreen> createState() => _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  final _search = TextEditingController();
  late Future<List<Map<String, Object?>>> _customers;

  @override
  void initState() { super.initState(); _reload(); }
  void _reload() => _customers = BusinessService.instance.customers(search: _search.text);

  Future<void> _addCustomer() async {
    final en = AppLanguage.english.value;
    final name = TextEditingController();
    final phone = TextEditingController();
    final address = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'Add customer' : 'نوی پېرودونکی'),
      content: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: InputDecoration(labelText: en ? 'Full name *' : 'بشپړ نوم *')),
        const SizedBox(height: 10),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: InputDecoration(labelText: en ? 'Phone number' : 'د ټیلیفون شمېره')),
        const SizedBox(height: 10),
        TextField(controller: address, decoration: InputDecoration(labelText: en ? 'Address' : 'پته')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () async {
          if (name.text.trim().isEmpty) return;
          await BusinessService.instance.saveCustomer(name: name.text, phone: phone.text, address: address.text);
          if (context.mounted) Navigator.pop(context, true);
        }, child: Text(en ? 'Save' : 'ثبت')),
      ],
    ));
    name.dispose(); phone.dispose(); address.dispose();
    if (result == true && mounted) setState(_reload);
  }

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return Column(children: [
      Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 10), child: Row(children: [
        Expanded(child: TextField(controller: _search, onChanged: (_) => setState(_reload), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: en ? 'Search by name or phone' : 'د نوم یا ټیلیفون له مخې لټون'))),
        const SizedBox(width: 8),
        FilledButton.tonalIcon(onPressed: _addCustomer, icon: const Icon(Icons.person_add_alt_1), label: Text(en ? 'Add' : 'نوی')),
      ])),
      Expanded(child: FutureBuilder<List<Map<String, Object?>>>(
        future: _customers,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('${snapshot.error}'));
          final items = snapshot.data ?? [];
          if (items.isEmpty) return Center(child: Text(en ? 'No customers found.' : 'پېرودونکی ونه موندل شو.'));
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final c = items[index];
              final balance = (c['balance'] as num).toInt();
              return Card(child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                title: Text(c['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text('${c['phone'] ?? (en ? 'No phone' : 'شمېره نشته')}\n${en ? 'Outstanding' : 'پاتې پور'}: ${_afn(balance)}'),
                isThreeLine: true,
                trailing: Icon(balance > 0 ? Icons.warning_amber_rounded : Icons.check_circle_outline, color: balance > 0 ? Colors.orange : Colors.green),
                onTap: () => _showCustomerDebts(c),
              ));
            },
          );
        },
      )),
    ]);
  }

  Future<void> _showCustomerDebts(Map<String, Object?> customer) async {
    final en = AppLanguage.english.value;
    final records = await BusinessService.instance.customerDebtHistory(customer['id'] as String);
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.76,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(customer['name'] as String, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            Text(customer['phone'] as String? ?? ''),
            const SizedBox(height: 12),
            Text(en ? 'Credit transaction history' : 'د نسیې معاملاتو تاریخچه', style: const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Expanded(child: records.isEmpty
              ? Center(child: Text(en ? 'No credit transactions.' : 'د نسیې معاملې نشته.'))
              : ListView.separated(
                  itemCount: records.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final d = records[index];
                    final due = DateFormat('dd MMM yyyy').format(DateTime.parse(d['due_at'] as String).toLocal());
                    final created = DateFormat('dd MMM yyyy').format(DateTime.parse(d['created_at'] as String).toLocal());
                    final status = d['status'] as String;
                    final statusText = status == 'PAID' ? (en ? 'PAID' : 'ورکړل شوی') : status == 'PARTIAL' ? (en ? 'PARTIALLY PAID' : 'یوه برخه ورکړل شوې') : (en ? 'OPEN' : 'پاتې پور');
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('${_afn(d['remaining'] as int)} • $statusText'),
                      subtitle: Text('${en ? 'Credit' : 'د پور نېټه'}: $created  •  ${en ? 'Due' : 'د ورکړې نېټه'}: $due\n${en ? 'Original' : 'اصلي'}: ${_afn(d['original_amount'] as int)}  •  ${en ? 'Paid' : 'ورکړل شوي'}: ${_afn(d['paid_amount'] as int)}'),
                      isThreeLine: true,
                      trailing: IconButton(
                        tooltip: en ? 'Payment history' : 'د پیسو تاریخچه',
                        icon: const Icon(Icons.receipt_long_outlined),
                        onPressed: () => _showDebtPaymentHistory(d['id'] as int),
                      ),
                    );
                  },
                )),
          ]),
        ),
      )),
    );
  }

  Future<void> _showDebtPaymentHistory(int debtId) async {
    final en = AppLanguage.english.value;
    final payments = await BusinessService.instance.debtPayments(debtId);
    if (!mounted) return;
    showDialog<void>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'Debt payment history' : 'د پور د ورکړې تاریخچه'),
      content: SizedBox(
        width: 360,
        height: 320,
        child: payments.isEmpty
          ? Center(child: Text(en ? 'No payments recorded.' : 'تر اوسه پیسې نه دي ثبت شوې.'))
          : ListView.separated(
              itemCount: payments.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final payment = payments[index];
                final date = DateTime.parse(payment['created_at'] as String).toLocal();
                final method = payment['payment_method'] == 'CARD' ? (en ? 'Card' : 'کارټ') : (en ? 'Cash' : 'نغدې');
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(_afn(payment['amount'] as int)),
                  subtitle: Text('${DateFormat('dd MMM yyyy, HH:mm').format(date)} • $method${(payment['note'] as String?)?.isNotEmpty == true ? ' • ${payment['note']}' : ''}'),
                );
              },
            ),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(en ? 'Close' : 'بندول'))],
    ));
  }

  String _afn(int value) => '${NumberFormat('#,##0').format(value)} AFN';
}
