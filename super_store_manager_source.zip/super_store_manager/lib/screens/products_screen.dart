import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../core/business_service.dart';
import '../main.dart';
import 'scanner_screen.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final _search = TextEditingController();
  late Future<List<Map<String, Object?>>> _items;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _items = BusinessService.instance.products(search: _search.text);

  Future<void> _openForm([Map<String, Object?>? product]) async {
    final result = await showDialog<bool>(context: context, builder: (_) => _ProductForm(product: product));
    if (result == true && mounted) setState(_reload);
  }

  Future<void> _archive(Map<String, Object?> product) async {
    final en = AppLanguage.english.value;
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(en ? 'Archive product?' : 'توکی له فعال لېست څخه وباسو؟'),
        content: Text(en ? 'Historical sales and inventory records will remain. The product will be hidden from normal lists.' : 'د دې توکي پخواني خرڅلاو او حسابونه به نه حذف کېږي؛ یوازې له فعال لېست څخه به پټ شي.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'نه')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(en ? 'Archive' : 'هو، وباسه')),
        ],
      ),
    );
    if (ok == true) {
      await BusinessService.instance.archiveProduct(product['id'] as String);
      if (mounted) setState(_reload);
    }
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
        child: Row(children: [
          Expanded(child: TextField(
            controller: _search,
            onChanged: (_) => setState(_reload),
            decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: en ? 'Search name, barcode or category' : 'د نوم، بارکوډ یا کټګورۍ لټون', suffixIcon: IconButton(onPressed: () { _search.clear(); setState(_reload); }, icon: const Icon(Icons.close))),
          )),
          const SizedBox(width: 8),
          FilledButton.tonalIcon(onPressed: () => _openForm(), icon: const Icon(Icons.add), label: Text(en ? 'Add' : 'نوی')),
        ]),
      ),
      Expanded(
        child: FutureBuilder<List<Map<String, Object?>>>(
          future: _items,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) return const Center(child: CircularProgressIndicator());
            if (snapshot.hasError) return Center(child: Text('${snapshot.error}'));
            final items = snapshot.data ?? [];
            if (items.isEmpty) return Center(child: Text(en ? 'No products yet. Add the first product.' : 'تر اوسه توکي نشته. لومړی توکی اضافه کړئ.'));
            return ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final p = items[index];
                final quantity = p['quantity'] as int;
                final minimum = p['minimum_quantity'] as int;
                final low = quantity <= minimum;
                final image = p['image_path'] as String?;
                return Card(
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                    leading: image != null && File(image).existsSync()
                        ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(File(image), width: 50, height: 50, fit: BoxFit.cover))
                        : CircleAvatar(backgroundColor: const Color(0xFFE0F2FE), child: const Icon(Icons.inventory_2_outlined, color: Color(0xFF155E75))),
                    title: Text(p['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 5),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${en ? 'Buy' : 'اخیستل'}: ${_afn(p['purchase_price'] as int)}   •   ${en ? 'Sell' : 'خرڅول'}: ${_afn(p['selling_price'] as int)}'),
                        Text('${en ? 'Stock' : 'سټاک'}: $quantity   •   ${p['barcode'] ?? (en ? 'No barcode' : 'بارکوډ نشته')}', style: TextStyle(color: low ? Colors.red : Colors.black54)),
                      ]),
                    ),
                    trailing: PopupMenuButton<String>(
                      onSelected: (value) { if (value == 'edit') { _openForm(p); } else if (value == 'history') { _showHistory(p); } else { _archive(p); } },
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'edit', child: Text(en ? 'Edit' : 'سمون')),
                        PopupMenuItem(value: 'history', child: Text(en ? 'Stock history' : 'د سټاک تاریخچه')),
                        PopupMenuItem(value: 'archive', child: Text(en ? 'Archive' : 'له لېست څخه ایستل')),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    ]);
  }

  Future<void> _showHistory(Map<String, Object?> product) async {
    final en = AppLanguage.english.value;
    final rows = await BusinessService.instance.inventoryHistory(productId: product['id'] as String);
    if (!mounted) return;
    showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (context) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * 0.68,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${product['name']} • ${en ? 'Stock history' : 'د سټاک تاریخچه'}', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Expanded(child: rows.isEmpty
              ? Center(child: Text(en ? 'No stock movements.' : 'د سټاک بدلونونه نشته.'))
              : ListView(children: rows.take(100).map((r) {
                  final delta = r['quantity_delta'] as int;
                  final date = DateTime.parse(r['created_at'] as String).toLocal();
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(delta < 0 ? Icons.south_west : Icons.north_east, color: delta < 0 ? Colors.red : Colors.green),
                    title: Text('${r['transaction_type']} • ${delta > 0 ? '+' : ''}$delta'),
                    subtitle: Text('${DateFormat('dd MMM yyyy, HH:mm').format(date)}  •  ${r['note'] ?? ''}'),
                    trailing: Text(_afn((r['unit_cost'] as int))),
                  );
                }).toList())),
        ]),
      ),
    )));
  }

  String _afn(int value) => '${NumberFormat('#,##0').format(value)} AFN';
}

class _ProductForm extends StatefulWidget {
  const _ProductForm({this.product});
  final Map<String, Object?>? product;

  @override
  State<_ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<_ProductForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _barcode;
  late final TextEditingController _category;
  late final TextEditingController _buy;
  late final TextEditingController _sell;
  late final TextEditingController _qty;
  late final TextEditingController _min;
  String? _expiry;
  String? _image;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    _name = TextEditingController(text: p?['name'] as String? ?? '');
    _barcode = TextEditingController(text: p?['barcode'] as String? ?? '');
    _category = TextEditingController(text: p?['category_name'] as String? ?? '');
    _buy = TextEditingController(text: p?['purchase_price']?.toString() ?? '0');
    _sell = TextEditingController(text: p?['selling_price']?.toString() ?? '0');
    _qty = TextEditingController(text: p?['quantity']?.toString() ?? '0');
    _min = TextEditingController(text: p?['minimum_quantity']?.toString() ?? '0');
    _expiry = p?['expiry_date'] as String?;
    _image = p?['image_path'] as String?;
  }

  @override
  void dispose() {
    for (final c in [_name, _barcode, _category, _buy, _sell, _qty, _min]) { c.dispose(); }
    super.dispose();
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const ScannerScreen()));
    if (code != null && mounted) setState(() => _barcode.text = code);
  }

  Future<void> _pickImage() async {
    final file = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 75, maxWidth: 1000);
    if (file == null) return;
    final root = await getApplicationDocumentsDirectory();
    final photoDir = Directory(p.join(root.path, 'product_photos'));
    await photoDir.create(recursive: true);
    final extension = p.extension(file.path).isEmpty ? '.jpg' : p.extension(file.path);
    final target = File(p.join(photoDir.path, 'product-${DateTime.now().microsecondsSinceEpoch}$extension'));
    await File(file.path).copy(target.path);
    if (mounted) setState(() => _image = target.path);
  }

  Future<void> _pickExpiry() async {
    final now = DateTime.now();
    final selected = await showDatePicker(context: context, initialDate: _expiry == null ? now : DateTime.parse(_expiry!), firstDate: DateTime(now.year - 2), lastDate: DateTime(now.year + 15));
    if (selected != null) setState(() => _expiry = DateFormat('yyyy-MM-dd').format(selected));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await BusinessService.instance.saveProduct(
        id: widget.product?['id'] as String?,
        name: _name.text,
        barcode: _barcode.text,
        category: _category.text,
        purchasePrice: int.parse(_buy.text),
        sellingPrice: int.parse(_sell.text),
        quantity: int.parse(_qty.text),
        minimumQuantity: int.parse(_min.text),
        expiryDate: _expiry,
        imagePath: _image,
      );
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    final editing = widget.product != null;
    return AlertDialog(
      title: Text(editing ? (en ? 'Edit product' : 'د توکي سمون') : (en ? 'New product' : 'نوی توکی')),
      content: SizedBox(
        width: 430,
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(children: [
              TextFormField(controller: _name, decoration: InputDecoration(labelText: en ? 'Product name *' : 'د توکي نوم *'), validator: (v) => v == null || v.trim().isEmpty ? (en ? 'Required' : 'دا برخه اړینه ده') : null),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: TextFormField(controller: _barcode, decoration: InputDecoration(labelText: en ? 'Barcode' : 'بارکوډ'))),
                IconButton(onPressed: _scan, icon: const Icon(Icons.qr_code_scanner), tooltip: en ? 'Scan barcode' : 'بارکوډ سکین'),
              ]),
              const SizedBox(height: 10),
              TextFormField(controller: _category, decoration: InputDecoration(labelText: en ? 'Category' : 'کټګوري')),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _numberField(_buy, en ? 'Purchase price (AFN)' : 'د اخیستلو بیه (AFN)')),
                const SizedBox(width: 8),
                Expanded(child: _numberField(_sell, en ? 'Selling price (AFN)' : 'د خرڅلاو بیه (AFN)')),
              ]),
              if (!editing) ...[
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _numberField(_qty, en ? 'Opening quantity' : 'لومړنی مقدار')),
                  const SizedBox(width: 8),
                  Expanded(child: _numberField(_min, en ? 'Minimum stock' : 'د کم سټاک حد')),
                ]),
              ] else ...[
                const SizedBox(height: 8),
                Text(en ? 'Current stock: ${widget.product!['quantity']}. Stock changes are made through purchases and adjustments.' : 'اوسنی سټاک: ${widget.product!['quantity']}. د سټاک بدلون د پېرود او تعدیل له لارې کېږي.'),
                const SizedBox(height: 10),
                _numberField(_min, en ? 'Minimum stock' : 'د کم سټاک حد'),
              ],
              const SizedBox(height: 10),
              OutlinedButton.icon(onPressed: _pickExpiry, icon: const Icon(Icons.event), label: Text(_expiry ?? (en ? 'Set expiry date' : 'د ختمېدو نېټه وټاکئ'))),
              const SizedBox(height: 6),
              OutlinedButton.icon(onPressed: _pickImage, icon: const Icon(Icons.camera_alt_outlined), label: Text(en ? 'Take product photo' : 'د توکي عکس واخلئ')),
              if (_image != null && File(_image!).existsSync()) Padding(padding: const EdgeInsets.only(top: 8), child: Image.file(File(_image!), height: 90)),
            ]),
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: _saving ? null : () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: _saving ? null : _save, child: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : Text(en ? 'Save' : 'ثبت')),
      ],
    );
  }

  Widget _numberField(TextEditingController controller, String label) => TextFormField(
    controller: controller,
    keyboardType: TextInputType.number,
    decoration: InputDecoration(labelText: label),
    validator: (v) {
      final n = int.tryParse(v ?? '');
      return n == null || n < 0 ? 'Enter 0 or more' : null;
    },
  );
}
