import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/business_service.dart';
import '../main.dart';

class DebtsScreen extends StatefulWidget {
  const DebtsScreen({super.key});

  @override
  State<DebtsScreen> createState() => _DebtsScreenState();
}

class _DebtsScreenState extends State<DebtsScreen> {
  late Future<List<Map<String, Object?>>> _debts;
  late Future<Map<String, int>> _summary;
  int _filter = 0;

  @override
  void initState() { super.initState(); _reload(); }

  String get _status => _filter == 1 ? 'OPEN' : _filter == 2 ? 'PARTIAL' : 'ALL';
  void _reload() {
    _debts = BusinessService.instance.debts(status: _status);
    _summary = BusinessService.instance.debtSummary();
  }

  Future<void> _pay(Map<String, Object?> debt) async {
    final en = AppLanguage.english.value;
    final amount = TextEditingController(text: '${debt['remaining']}');
    final payments = await BusinessService.instance.debtPayments(debt['id'] as int);
    String paymentMethod = 'CASH';
    if (!mounted) return;
    final result = await showDialog<Map<String, Object?>>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: Text(en ? 'Receive customer payment' : 'د پېرودونکي پیسې ترلاسه کول'),
      content: SizedBox(width: 420, child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${debt['customer_name']}  •  ${debt['customer_phone'] ?? ''}'),
        const SizedBox(height: 8),
        Text('${en ? 'Original' : 'اصلي پور'}: ${_afn(debt['original_amount'] as int)}'),
        Text('${en ? 'Previously paid' : 'تر اوسه ورکړل شوي'}: ${_afn(debt['paid_amount'] as int)}'),
        Text('${en ? 'Remaining' : 'پاتې'}: ${_afn(debt['remaining'] as int)}', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Payment amount (AFN)' : 'د ورکړې اندازه (AFN)')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: paymentMethod, decoration: InputDecoration(labelText: en ? 'Payment method' : 'د ورکړې طریقه'), items: [DropdownMenuItem(value: 'CASH', child: Text(en ? 'Cash' : 'نغدې')), DropdownMenuItem(value: 'CARD', child: Text(en ? 'Card' : 'کارت'))], onChanged: (v) => setDialog(() => paymentMethod = v ?? 'CASH')),
        const SizedBox(height: 12),
        Text(en ? 'Previous payments' : 'پخوانۍ ورکړې', style: const TextStyle(fontWeight: FontWeight.bold)),
        if (payments.isEmpty) Text(en ? 'No payments recorded.' : 'تر اوسه ورکړه نه ده ثبت شوې.'),
        ...payments.take(4).map((p) => Text('${_afn(p['amount'] as int)} • ${DateFormat('dd MMM yyyy').format(DateTime.parse(p['created_at'] as String).toLocal())}')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () {
          final value = int.tryParse(amount.text);
          if (value == null || value <= 0 || value > (debt['remaining'] as int)) return;
          Navigator.pop(context, {'amount': value, 'method': paymentMethod});
        }, child: Text(en ? 'Save payment' : 'ورکړه ثبت کړه')),
      ],
    )));
    amount.dispose();
    if (result == null) return;
    try {
      await BusinessService.instance.recordDebtPayment(debtId: debt['id'] as int, amount: result['amount'] as int, method: result['method'] as String);
      if (mounted) {
        setState(_reload);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Payment saved. Debt balance updated.' : 'ورکړه ثبت شوه او پاتې پور تازه شو.')));
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return Column(children: [
      SizedBox(height: 102, child: FutureBuilder<Map<String, int>>(future: _summary, builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)));
        final m = snapshot.data!;
        return ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.fromLTRB(12, 6, 12, 8), children: [
          _summaryCard(en ? 'Total debt' : 'ټول پاتې پور', m['total'] ?? 0, Icons.account_balance_wallet),
          _summaryCard(en ? 'Overdue' : 'له نېټې تېر', m['overdue'] ?? 0, Icons.warning_amber_rounded),
          _summaryCard(en ? 'Due today' : 'نن د ورکړې', m['due_today'] ?? 0, Icons.today),
          _summaryCard(en ? 'Due in 7 days' : 'په ۷ ورځو کې', m['due_seven'] ?? 0, Icons.event),
          _summaryCard(en ? 'Collected' : 'راټولې شوې', m['collected'] ?? 0, Icons.payments),
          _summaryCard(en ? 'Customers' : 'پېرودونکي', m['customers'] ?? 0, Icons.people),
        ]);
      })),
      Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 10), child: SegmentedButton<int>(
        segments: [
          ButtonSegment(value: 0, label: Text(en ? 'All open' : 'ټول پاتې'), icon: const Icon(Icons.list_alt)),
          ButtonSegment(value: 1, label: Text(en ? 'Unpaid' : 'نه دي ورکړل شوي')),
          ButtonSegment(value: 2, label: Text(en ? 'Partial' : 'نیمګړي')),
        ],
        selected: {_filter},
        onSelectionChanged: (value) => setState(() { _filter = value.first; _reload(); }),
      )),
      Expanded(child: FutureBuilder<List<Map<String, Object?>>>(
        future: _debts,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return Center(child: Text('${snapshot.error}'));
          final items = snapshot.data ?? [];
          if (items.isEmpty) return Center(child: Text(en ? 'No outstanding debt transactions.' : 'ناخلاصې پور معاملې نشته.'));
          final today = DateTime.now();
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final d = items[index];
              final due = DateTime.parse(d['due_at'] as String);
              final isOverdue = DateTime(due.year, due.month, due.day).isBefore(DateTime(today.year, today.month, today.day));
              final dueToday = due.year == today.year && due.month == today.month && due.day == today.day;
              final color = isOverdue ? Colors.red : dueToday ? Colors.orange : Colors.teal;
              final status = isOverdue ? (en ? 'OVERDUE' : 'له نېټې تېر') : dueToday ? (en ? 'DUE TODAY' : 'نن د ورکړې نېټه') : d['status'] == 'PARTIAL' ? (en ? 'PARTIALLY PAID' : 'یوه برخه ورکړل شوې') : (en ? 'UPCOMING' : 'راتلونکی');
              return Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Expanded(child: Text(d['customer_name'] as String, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)), child: Text(status, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 11))),
                ]),
                const SizedBox(height: 5),
                Text('${d['customer_phone'] ?? ''}  •  ${en ? 'Due' : 'د ورکړې نېټه'}: ${DateFormat('dd MMM yyyy').format(due)}'),
                const SizedBox(height: 8),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Text('${en ? 'Original' : 'اصلي'}: ${_afn(d['original_amount'] as int)}'),
                  Text('${en ? 'Paid' : 'ورکړل شوي'}: ${_afn(d['paid_amount'] as int)}'),
                ]),
                const Divider(height: 16),
                Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(en ? 'Remaining balance' : 'پاتې پور', style: const TextStyle(color: Colors.black54)), Text(_afn(d['remaining'] as int), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19))])),
                  FilledButton.icon(onPressed: () => _pay(d), icon: const Icon(Icons.payments_outlined), label: Text(en ? 'Receive payment' : 'پیسې واخله')),
                ]),
              ])));
            },
          );
        },
      )),
    ]);
  }

  Widget _summaryCard(String label, int value, IconData icon) => Container(
    width: 150, margin: const EdgeInsets.symmetric(horizontal: 4), padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
      Row(children: [Icon(icon, size: 16, color: const Color(0xFF155E75)), const SizedBox(width: 5), Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.black54))) ]),
      Text(_afn(value), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
    ]),
  );

  String _afn(int value) => '${NumberFormat('#,##0').format(value)} AFN';
}
