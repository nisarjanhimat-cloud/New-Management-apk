import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:sqflite_sqlcipher/sqflite.dart';

import '../core/business_service.dart';
import '../core/backup_service.dart';
import '../core/database_service.dart';
import '../core/report_export_service.dart';
import '../main.dart';

class MoreScreen extends StatefulWidget {
  const MoreScreen({super.key, required this.onLock});
  final VoidCallback onLock;

  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  String _afn(int value) => '${NumberFormat('#,##0').format(value)} AFN';

  Future<void> _setLanguage(bool english) async {
    AppLanguage.english.value = english;
    final db = await DatabaseService.instance.database;
    await db.insert('settings', {
      'key': 'language', 'value': english ? 'en' : 'ps',
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
    if (mounted) setState(() {});
  }

  Future<String?> _askBackupPassword(String title, String label) async {
    final en = AppLanguage.english.value;
    final controller = TextEditingController();
    final result = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: Text(title),
      content: TextField(controller: controller, obscureText: true, decoration: InputDecoration(labelText: label)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () { if (controller.text.length >= 10) Navigator.pop(context, controller.text); }, child: Text(en ? 'Continue' : 'دوام')),
      ],
    ));
    controller.dispose();
    return result;
  }

  Future<void> _exportExcel() async {
    final en = AppLanguage.english.value;
    try {
      await ReportExportService.instance.exportExcelWorkbook();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${en ? 'Excel export failed' : 'د Excel راپور جوړول ناکام شول'}: $e')),
      );
    }
  }

  Future<void> _exportPdf() async {
    final en = AppLanguage.english.value;
    try {
      await ReportExportService.instance.exportFinancialPdf();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${en ? 'PDF export failed' : 'د PDF راپور جوړول ناکام شول'}: $e')),
      );
    }
  }

  Future<void> _backup() async {
    final en = AppLanguage.english.value;
    final password = await _askBackupPassword(en ? 'Encrypt backup' : 'بیک‌اپ کوډ کول', en ? 'Backup password (10+ characters)' : 'د بیک‌اپ پټنوم (لږ تر لږه ۱۰ توري)');
    if (password == null) return;
    try {
      await BackupService.instance.createEncryptedBackup(password);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Encrypted backup created. Keep the backup password separately.' : 'کوډ شوی بیک‌اپ جوړ شو؛ پټنوم یې جلا او خوندي وساتئ.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> _restore() async {
    final en = AppLanguage.english.value;
    final confirm = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'Replace local data?' : 'موجود معلومات بدل شي؟'),
      content: Text(en ? 'Restore replaces the current local database with the selected backup. Make a backup of the current data first.' : 'بېرته راوستل به اوسني معلومات د بیک‌اپ په معلوماتو بدل کړي. لومړی د اوسنیو معلوماتو بیک‌اپ واخلئ.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')), FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(en ? 'Continue' : 'دوام'))],
    ));
    if (confirm != true) return;
    final password = await _askBackupPassword(en ? 'Decrypt backup' : 'بیک‌اپ خلاصول', en ? 'Backup password' : 'د بیک‌اپ پټنوم');
    if (password == null) return;
    try {
      await BackupService.instance.restoreEncryptedBackup(password);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Backup restored.' : 'بیک‌اپ بېرته راوستل شو.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${en ? 'Restore failed' : 'بېرته راوستل ناکام شول'}: $e')));
    }
  }

  Future<void> _addExpense() async {
    final en = AppLanguage.english.value;
    final title = TextEditingController();
    final amount = TextEditingController();
    final category = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'Record expense' : 'لګښت ثبتول'),
      content: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, decoration: InputDecoration(labelText: en ? 'Expense title' : 'د لګښت نوم')),
        const SizedBox(height: 10),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Amount (AFN)' : 'اندازه (AFN)')),
        const SizedBox(height: 10),
        TextField(controller: category, decoration: InputDecoration(labelText: en ? 'Category' : 'کټګوري')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () async {
          final value = int.tryParse(amount.text);
          if (value == null || value <= 0 || title.text.trim().isEmpty) return;
          await BusinessService.instance.addExpense(title: title.text, amount: value, category: category.text);
          if (context.mounted) Navigator.pop(context, true);
        }, child: Text(en ? 'Save' : 'ثبت')),
      ],
    ));
    title.dispose(); amount.dispose(); category.dispose();
    if (result == true && mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Expense recorded.' : 'لګښت ثبت شو.')));
  }

  Future<void> _addSupplier() async {
    final en = AppLanguage.english.value;
    final name = TextEditingController();
    final phone = TextEditingController();
    final address = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'New supplier' : 'نوی عرضه کوونکی'),
      content: SizedBox(width: 400, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: InputDecoration(labelText: en ? 'Supplier name' : 'د عرضه کوونکي نوم')),
        const SizedBox(height: 10),
        TextField(controller: phone, decoration: InputDecoration(labelText: en ? 'Phone' : 'ټیلیفون')),
        const SizedBox(height: 10),
        TextField(controller: address, decoration: InputDecoration(labelText: en ? 'Address' : 'پته')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () async {
          if (name.text.trim().isEmpty) return;
          await BusinessService.instance.saveSupplier(name: name.text, phone: phone.text, address: address.text);
          if (context.mounted) Navigator.pop(context, true);
        }, child: Text(en ? 'Save' : 'ثبت')),
      ],
    ));
    name.dispose(); phone.dispose(); address.dispose();
    if (result == true && mounted) _showSuppliers();
  }

  Future<void> _showSuppliers() async {
    final en = AppLanguage.english.value;
    final items = await BusinessService.instance.suppliers();
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.72,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [Expanded(child: Text(en ? 'Suppliers' : 'عرضه کوونکي', style: Theme.of(context).textTheme.titleLarge)), IconButton(onPressed: () { Navigator.pop(context); _addSupplier(); }, icon: const Icon(Icons.add))]),
            Expanded(child: items.isEmpty
              ? Center(child: Text(en ? 'No suppliers yet.' : 'عرضه کوونکي نه دي ثبت شوي.'))
              : ListView(children: items.map((s) => ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const CircleAvatar(child: Icon(Icons.local_shipping_outlined)),
                  title: Text(s['name'] as String),
                  subtitle: Text('${s['phone'] ?? ''}  •  ${en ? 'Balance' : 'پاتې پور'}: ${_afn((s['balance'] as num).toInt())}'),
                )).toList())),
          ]),
        ),
      )),
    );
  }

  Future<void> _recordSalesReturn() async {
    final en = AppLanguage.english.value;
    final db = await DatabaseService.instance.database;
    final sales = await db.rawQuery('''
      SELECT s.id, s.created_at, s.total_amount, c.name AS customer_name
      FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
      WHERE COALESCE(s.credit_amount,0)=0
      ORDER BY s.created_at DESC LIMIT 100
    ''');
    if (!mounted) return;
    if (sales.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'No completed sales found.' : 'ثبت شوی خرڅلاو ونه موندل شو.')));
      return;
    }
    final saleId = await showModalBottomSheet<String>(context: context, isScrollControlled: true, builder: (context) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * 0.65,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        Text(en ? 'Select original sale' : 'اصلي خرڅلاو وټاکئ', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        ...sales.map((sale) {
          final date = DateTime.parse(sale['created_at'] as String).toLocal();
          return ListTile(
            title: Text('${sale['customer_name'] ?? (en ? 'Walk-in customer' : 'عادي پېرودونکی')} • ${_afn(sale['total_amount'] as int)}'),
            subtitle: Text(DateFormat('dd MMM yyyy, HH:mm').format(date)),
            onTap: () => Navigator.pop(context, sale['id'] as String),
          );
        }),
      ]),
    )));
    if (saleId == null || !mounted) return;
    final items = await db.rawQuery('''
      SELECT si.*,
        (si.quantity-COALESCE((SELECT SUM(sr.quantity) FROM sales_returns sr WHERE sr.sale_item_id=si.id),0)) AS remaining_quantity,
        COALESCE((SELECT SUM(sr.quantity) FROM sales_returns sr WHERE sr.sale_item_id=si.id),0) AS returned_quantity,
        COALESCE((SELECT SUM(sr.refund_amount) FROM sales_returns sr WHERE sr.sale_item_id=si.id),0) AS prior_refund
      FROM sale_items si WHERE si.sale_id=? ORDER BY si.product_name
    ''', [saleId]);
    final returnable = items.where((item) => (item['remaining_quantity'] as int) > 0).toList();
    if (returnable.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'All items on this sale have already been returned.' : 'د دې خرڅلاو ټول توکي مخکې بېرته منل شوي دي.')));
      return;
    }
    int maximumRefundFor(Map<String, Object?> item, int quantityToReturn) {
      if (quantityToReturn <= 0) return 0;
      final sold = item['quantity'] as int;
      final alreadyReturned = item['returned_quantity'] as int;
      final alreadyRefunded = item['prior_refund'] as int;
      final netLine = item['line_total'] as int;
      return (netLine * (alreadyReturned + quantityToReturn) ~/ sold) - alreadyRefunded;
    }

    String selectedItem = returnable.first['id'] as String;
    final quantity = TextEditingController(text: '1');
    final refund = TextEditingController(text: '${maximumRefundFor(returnable.first, 1)}');
    final reason = TextEditingController();
    bool restock = true;
    String refundMethod = 'CASH';
    final ok = await showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialog) {
      final selected = returnable.firstWhere((item) => item['id'] == selectedItem);
      final q = int.tryParse(quantity.text) ?? 0;
      final maximum = maximumRefundFor(selected, q);
      return AlertDialog(
        title: Text(en ? 'Record returned item' : 'بېرته راغلی توکی ثبتول'),
        content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(
            value: selectedItem, isExpanded: true,
            decoration: InputDecoration(labelText: en ? 'Sale item' : 'د خرڅلاو توکی'),
            items: returnable.map((item) => DropdownMenuItem(value: item['id'] as String, child: Text('${item['product_name']} • ${item['remaining_quantity']} ${en ? 'left' : 'پاتې'}'))).toList(),
            onChanged: (v) => setDialog(() {
              selectedItem = v!;
              quantity.text = '1';
              final line = returnable.firstWhere((item) => item['id'] == selectedItem);
              refund.text = '${maximumRefundFor(line, 1)}';
            }),
          ),
          const SizedBox(height: 10),
          TextField(controller: quantity, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Return quantity (max ${selected['remaining_quantity']})' : 'د بېرته ستنولو مقدار (تر ${selected['remaining_quantity']} پورې)'), onChanged: (_) => setDialog(() {
            refund.text = '${maximumRefundFor(selected, int.tryParse(quantity.text) ?? 0)}';
          })),
          const SizedBox(height: 10),
          TextField(controller: refund, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Refund amount (AFN, max $maximum)' : 'د پیسو بېرته ورکړه (AFN، تر $maximum پورې')),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: refundMethod,
            decoration: InputDecoration(labelText: en ? 'Refund method' : 'د پیسو د بېرته ورکولو طریقه'),
            items: [
              DropdownMenuItem(value: 'CASH', child: Text(en ? 'Cash refund' : 'نغدې پیسې')),
              DropdownMenuItem(value: 'CARD', child: Text(en ? 'Card refund' : 'کارټ ته بېرته ورکړه')),
            ],
            onChanged: (v) => setDialog(() => refundMethod = v ?? 'CASH'),
          ),
          const SizedBox(height: 8),
          CheckboxListTile(value: restock, contentPadding: EdgeInsets.zero, onChanged: (v) => setDialog(() => restock = v ?? true), title: Text(en ? 'Return item to available stock' : 'توکی بېرته موجود سټاک ته داخل کړه')),
          TextField(controller: reason, decoration: InputDecoration(labelText: en ? 'Reason / note' : 'لامل / یادښت')),
        ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
          FilledButton(onPressed: () {
            final qn = int.tryParse(quantity.text);
            final rn = int.tryParse(refund.text);
            if (qn == null || qn <= 0 || qn > (selected['remaining_quantity'] as int) || rn == null || rn < 0 || rn > maximumRefundFor(selected, qn)) return;
            Navigator.pop(context, true);
          }, child: Text(en ? 'Save return' : 'بېرته ستنول ثبت کړه')),
        ],
      );
    }));
    if (ok == true) {
      try {
        await BusinessService.instance.recordSalesReturn(
          saleId: saleId,
          saleItemId: selectedItem,
          quantity: int.parse(quantity.text),
          refundAmount: int.parse(refund.text),
          restock: restock,
          refundMethod: refundMethod,
          reason: reason.text.trim(),
        );
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Return and refund recorded.' : 'د توکي بېرته ستنول او پیسې ثبت شوې.')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
    quantity.dispose(); refund.dispose(); reason.dispose();
  }

  Future<void> _adjustStock() async {
    final en = AppLanguage.english.value;
    final products = await BusinessService.instance.products();
    if (!mounted) return;
    if (products.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Add products first.' : 'لومړی توکي ثبت کړئ.')));
      return;
    }
    String selectedProduct = products.first['id'] as String;
    String reason = 'DAMAGED';
    final quantity = TextEditingController(text: '1');
    final note = TextEditingController();
    final result = await showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: Text(en ? 'Stock adjustment' : 'د سټاک تعدیل'),
      content: SizedBox(width: 420, child: Column(mainAxisSize: MainAxisSize.min, children: [
        DropdownButtonFormField<String>(
          value: selectedProduct, isExpanded: true,
          decoration: InputDecoration(labelText: en ? 'Product' : 'توکی'),
          items: products.map((p) => DropdownMenuItem(value: p['id'] as String, child: Text('${p['name']} (${p['quantity']})'))).toList(),
          onChanged: (v) => setDialog(() => selectedProduct = v!),
        ),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: reason,
          decoration: InputDecoration(labelText: en ? 'Reason' : 'لامل'),
          items: [
            DropdownMenuItem(value: 'DAMAGED', child: Text(en ? 'Damaged / lost (decrease)' : 'خراب / ورک (کموالی)')),
            DropdownMenuItem(value: 'RETURNED_STOCK', child: Text(en ? 'Returned to stock (increase)' : 'بېرته سټاک ته داخلول (زیاتوالی)')),
            DropdownMenuItem(value: 'CORRECTION_IN', child: Text(en ? 'Stock correction (increase)' : 'د سټاک اصلاح (زیاتوالی)')),
            DropdownMenuItem(value: 'CORRECTION_OUT', child: Text(en ? 'Stock correction (decrease)' : 'د سټاک اصلاح (کموالی)')),
          ],
          onChanged: (v) => setDialog(() => reason = v ?? 'DAMAGED'),
        ),
        const SizedBox(height: 10),
        TextField(controller: quantity, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Quantity' : 'مقدار')),
        const SizedBox(height: 10),
        TextField(controller: note, decoration: InputDecoration(labelText: en ? 'Note (optional)' : 'یادښت (اختیاري)')),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
        FilledButton(onPressed: () {
          final q = int.tryParse(quantity.text);
          if (q == null || q <= 0) return;
          Navigator.pop(context, true);
        }, child: Text(en ? 'Save adjustment' : 'تعدیل ثبت کړه')),
      ],
    )));
    if (result == true) {
      final q = int.parse(quantity.text);
      final decrease = reason == 'DAMAGED' || reason == 'CORRECTION_OUT';
      try {
        await BusinessService.instance.adjustStock(
          productId: selectedProduct,
          quantityDelta: decrease ? -q : q,
          reason: reason,
          note: note.text.trim(),
        );
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Stock updated.' : 'سټاک تازه شو.')));
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
    quantity.dispose(); note.dispose();
  }

  Future<void> _showInventoryMovements() async {
    final en = AppLanguage.english.value;
    final rows = await BusinessService.instance.inventoryHistory(limit: 100);
    if (!mounted) return;
    showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (context) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * 0.72,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(en ? 'Recent inventory movements' : 'د سټاک وروستي بدلونونه', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Expanded(child: rows.isEmpty
            ? Center(child: Text(en ? 'No inventory movements.' : 'د سټاک بدلونونه نشته.'))
            : ListView(children: rows.take(100).map((r) {
                final delta = r['quantity_delta'] as int;
                final when = DateTime.parse(r['created_at'] as String).toLocal();
                return ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('${r['product_name']} • ${r['transaction_type']}'),
                  subtitle: Text('${DateFormat('dd MMM yyyy, HH:mm').format(when)} • ${r['note'] ?? ''}'),
                  trailing: Text('${delta > 0 ? '+' : ''}$delta', style: TextStyle(fontWeight: FontWeight.bold, color: delta < 0 ? Colors.red : Colors.green)),
                );
              }).toList())),
        ]),
      ),
    )));
  }

  Future<void> _recordPurchase() async {
    final en = AppLanguage.english.value;
    final products = await BusinessService.instance.products();
    final suppliers = await BusinessService.instance.suppliers();
    if (!mounted) return;
    if (products.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Add products first.' : 'لومړی توکي ثبت کړئ.')));
      return;
    }
    String selectedProduct = products.first['id'] as String;
    String? selectedSupplier = suppliers.isEmpty ? null : suppliers.first['id'] as String;
    final quantity = TextEditingController(text: '1');
    final unitCost = TextEditingController(text: '${products.first['purchase_price']}');
    final paid = TextEditingController(text: '0');
    final invoice = TextEditingController();
    String? error;
    final ok = await showDialog<bool>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialog) {
      final product = products.firstWhere((p) => p['id'] == selectedProduct);
      final q = int.tryParse(quantity.text) ?? 0;
      final unitPrice = int.tryParse(unitCost.text) ?? (product['purchase_price'] as int);
      final total = q * unitPrice;
      return AlertDialog(
        title: Text(en ? 'Record stock purchase' : 'د سټاک پېرود ثبتول'),
        content: SizedBox(width: 420, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          DropdownButtonFormField<String>(value: selectedProduct, isExpanded: true, decoration: InputDecoration(labelText: en ? 'Product' : 'توکی'), items: products.map((p) => DropdownMenuItem(value: p['id'] as String, child: Text(p['name'] as String))).toList(), onChanged: (v) => setDialog(() => selectedProduct = v!)),
          const SizedBox(height: 10),
          if (suppliers.isNotEmpty) DropdownButtonFormField<String?>(value: selectedSupplier, isExpanded: true, decoration: InputDecoration(labelText: en ? 'Supplier' : 'عرضه کوونکی'), items: [const DropdownMenuItem(value: null, child: Text('—')), ...suppliers.map((s) => DropdownMenuItem(value: s['id'] as String, child: Text(s['name'] as String)))], onChanged: (v) => setDialog(() => selectedSupplier = v)),
          const SizedBox(height: 10),
          TextField(controller: quantity, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Quantity' : 'مقدار'), onChanged: (_) => setDialog(() {})),
          const SizedBox(height: 10),
          TextField(controller: unitCost, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Unit purchase cost (AFN)' : 'د یوې دانې د اخیستلو بیه (AFN)'), onChanged: (_) => setDialog(() {})),
          const SizedBox(height: 8),
          Text('${en ? 'Purchase total' : 'د پېرود ټول قیمت'}: ${_afn(total)}', style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(controller: paid, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Amount paid now' : 'اوس ورکړل شوې پیسې')),
          const SizedBox(height: 10),
          TextField(controller: invoice, decoration: InputDecoration(labelText: en ? 'Supplier invoice number' : 'د عرضه کوونکي د بل شمېره')),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
        ]))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(en ? 'Cancel' : 'لغوه')),
          FilledButton(onPressed: () {
            final qn = int.tryParse(quantity.text) ?? 0;
            final pn = int.tryParse(paid.text) ?? -1;
            final cost = int.tryParse(unitCost.text) ?? -1;
            final amount = qn * cost;
            if (qn <= 0 || cost < 0 || pn < 0 || pn > amount) { setDialog(() => error = en ? 'Check quantity and payment amount.' : 'مقدار او ورکړل شوې پیسې سمې کړئ.'); return; }
            Navigator.pop(context, true);
          }, child: Text(en ? 'Save purchase' : 'پېرود ثبت کړه')),
        ],
      );
    }));
    if (ok == true) {
      await BusinessService.instance.recordPurchase(
        supplierId: selectedSupplier,
        lines: [SaleLine(productId: selectedProduct, quantity: int.parse(quantity.text), unitCost: int.parse(unitCost.text))],
        amountPaid: int.parse(paid.text),
        invoiceNumber: invoice.text,
      );
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(en ? 'Purchase saved. Stock increased by ${quantity.text}.' : 'پېرود ثبت شو او سټاک زیات شو.')));
    }
    quantity.dispose(); unitCost.dispose(); paid.dispose(); invoice.dispose();
  }

  Future<void> _showPurchaseInvoices() async {
    final en = AppLanguage.english.value;
    final db = await DatabaseService.instance.database;
    final rows = await db.rawQuery('''
      SELECT p.*, s.name AS supplier_name, (p.total_amount-p.amount_paid) AS balance
      FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id
      ORDER BY p.created_at DESC LIMIT 100
    ''');
    if (!mounted) return;
    showModalBottomSheet<void>(context: context, isScrollControlled: true, builder: (context) => SafeArea(child: SizedBox(
      height: MediaQuery.of(context).size.height * 0.72,
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(children: [
          Text(en ? 'Purchase invoices and supplier balances' : 'د پېرود بلونه او د عرضه کوونکو پورونه', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          Expanded(child: rows.isEmpty
            ? Center(child: Text(en ? 'No purchase invoices.' : 'د پېرود بلونه نشته.'))
            : ListView(children: rows.map((p) => ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('${p['supplier_name'] ?? (en ? 'Unassigned supplier' : 'عرضه کوونکی نه دی ټاکل شوی')}  •  ${_afn(p['total_amount'] as int)}'),
                subtitle: Text('${en ? 'Paid' : 'ورکړل شوي'}: ${_afn(p['amount_paid'] as int)}  •  ${en ? 'Balance' : 'پاتې'}: ${_afn(p['balance'] as int)}'),
                trailing: (p['balance'] as int) > 0 ? IconButton(icon: const Icon(Icons.payments_outlined), onPressed: () { Navigator.pop(context); _paySupplier(p); }) : const Icon(Icons.check_circle, color: Colors.green),
              )).toList())),
        ]),
      ),
    )));
  }

  Future<void> _paySupplier(Map<String, Object?> purchase) async {
    final en = AppLanguage.english.value;
    final amount = TextEditingController(text: '${purchase['balance']}');
    final result = await showDialog<int>(context: context, builder: (context) => AlertDialog(
      title: Text(en ? 'Pay supplier balance' : 'عرضه کوونکي ته د پور ورکړه'),
      content: TextField(controller: amount, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Amount (AFN)' : 'اندازه (AFN)')),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(en ? 'Cancel' : 'لغوه')), FilledButton(onPressed: () { final n = int.tryParse(amount.text); if (n != null && n > 0 && n <= (purchase['balance'] as int)) Navigator.pop(context, n); }, child: Text(en ? 'Save' : 'ثبت'))],
    ));
    amount.dispose();
    if (result != null) {
      await BusinessService.instance.paySupplierInvoice(purchaseId: purchase['id'] as String, amount: result);
      if (mounted) _showPurchaseInvoices();
    }
  }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return Scaffold(
      appBar: AppBar(title: Text(en ? 'More and settings' : 'نور امکانات او تنظیمات')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: SwitchListTile(
          value: !en,
          onChanged: (pashto) => _setLanguage(!pashto),
          title: Text(en ? 'Pashto interface' : 'پښتو ژبه'),
          subtitle: Text(en ? 'Switch between Pashto and English.' : 'د پښتو او انګلیسي ترمنځ ژبه بدله کړئ.'),
          secondary: const Icon(Icons.translate),
        )),
        const SizedBox(height: 8),
        _option(Icons.local_shipping_outlined, en ? 'Supplier management' : 'د عرضه کوونکو مدیریت', en ? 'Add suppliers and view balances' : 'عرضه کوونکي او پاتې پورونه', _showSuppliers),
        _option(Icons.add_shopping_cart, en ? 'Record purchase' : 'د توکو پېرود', en ? 'Increase stock and track supplier credit' : 'سټاک زیات او د عرضه کوونکي پور ثبت کړئ', _recordPurchase),
        _option(Icons.assignment_return_outlined, en ? 'Sales returns and refunds' : 'د خرڅلاو بېرته ستنول', en ? 'Record an item return, restock and refund' : 'بېرته راغلی توکی، سټاک او پیسې ثبت کړئ', _recordSalesReturn),
        _option(Icons.tune, en ? 'Adjust inventory' : 'د سټاک تعدیل', en ? 'Record damaged, returned and corrected stock' : 'خراب، بېرته راغلي او اصلاح شوي توکي ثبت کړئ', _adjustStock),
        _option(Icons.history, en ? 'Inventory movement history' : 'د سټاک د بدلون تاریخچه', en ? 'Review recent stock in and out' : 'د سټاک وروستي داخل او خارج وګورئ', _showInventoryMovements),
        _option(Icons.receipt_long, en ? 'Purchase invoices' : 'د پېرود بلونه', en ? 'Review invoices and pay balances' : 'بلونه وګورئ او پاتې پیسې ورکړئ', _showPurchaseInvoices),
        _option(Icons.money_off_csred_outlined, en ? 'Record expense' : 'لګښت ثبتول', en ? 'Rent, salary, utilities and other expenses' : 'کرایه، معاش، برېښنا او نور لګښتونه', _addExpense),
        _option(Icons.table_view_outlined, en ? 'Export Excel reports' : 'Excel راپور صادرول', en ? 'Products, debts, sales, expenses and purchases' : 'توکي، پورونه، خرڅلاو، لګښتونه او پېرود', _exportExcel),
        _option(Icons.picture_as_pdf_outlined, en ? 'Export financial PDF' : 'مالي PDF راپور صادرول', en ? 'Share dashboard financial summary' : 'د مالي داشبورډ لنډ راپور شریک کړئ', _exportPdf),
        _option(Icons.cloud_upload_outlined, en ? 'Create encrypted backup' : 'کوډ شوی بیک‌اپ جوړول', en ? 'Export a password-protected backup file' : 'د پټنوم په وسیله خوندي شوی فایل جوړ کړئ', _backup),
        _option(Icons.settings_backup_restore, en ? 'Restore backup' : 'بیک‌اپ بېرته راوستل', en ? 'Replace local data from a backup file' : 'له بیک‌اپ څخه معلومات بېرته راوستل', _restore),
        _option(Icons.lock_outline, en ? 'Lock application' : 'اپلېکېشن قلف کول', en ? 'Require owner password again' : 'د مالک پټنوم بیا وغواړئ', widget.onLock),
        const SizedBox(height: 14),
        Text(en ? 'Important' : 'مهم', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        Text(en
            ? 'This source build keeps operational records in an encrypted on-device SQLCipher database. The PostgreSQL API is only a deployment scaffold; the app does not yet synchronize with it. PDF summary uses English labels, and product photos are stored as local file paths rather than included in the backup.'
            : 'دا سرچینه معلومات په کوډ شوي SQLCipher ډیټابېس کې ساتي. PostgreSQL API یوازې د سرور د برابرولو چوکاټ دی؛ اپلېکېشن تر اوسه ورسره معلومات نه همغږي کوي. د PDF لنډ راپور انګلیسي سرلیکونه لري او د محصول عکسونه د بیک‌اپ برخه نه دي.'),
      ]),
    );
  }

  Widget _option(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(child: ListTile(
    leading: CircleAvatar(backgroundColor: const Color(0xFFE0F2FE), child: Icon(icon, color: const Color(0xFF155E75))),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Text(subtitle),
    trailing: const Icon(Icons.chevron_right),
    onTap: onTap,
  ));
}
