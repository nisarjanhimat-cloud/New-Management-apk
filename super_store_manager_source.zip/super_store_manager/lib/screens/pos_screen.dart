import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/business_service.dart';
import '../main.dart';
import 'scanner_screen.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  final _search = TextEditingController();
  final Map<String, int> _cart = {};
  final Map<String, int> _priceById = {};
  final Map<String, String> _nameById = {};
  late Future<List<Map<String, Object?>>> _products;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  void _reload() => _products = BusinessService.instance.products(search: _search.text);

  int _totalFor(List<Map<String, Object?>> products) {
    for (final p in products) {
      _priceById[p['id'] as String] = p['selling_price'] as int;
      _nameById[p['id'] as String] = p['name'] as String;
    }
    return _cart.entries.fold(0, (sum, entry) => sum + entry.value * (_priceById[entry.key] ?? 0));
  }

  void _add(Map<String, Object?> product) {
    final id = product['id'] as String;
    _priceById[id] = product['selling_price'] as int;
    _nameById[id] = product['name'] as String;
    final stock = product['quantity'] as int;
    final next = (_cart[id] ?? 0) + 1;
    if (next > stock) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLanguage.english.value ? 'Not enough stock.' : 'په سټاک کې دا اندازه نشته.')));
      return;
    }
    setState(() => _cart[id] = next);
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const ScannerScreen()));
    if (code == null) return;
    final db = await BusinessService.instance.products(search: code);
    final match = db.where((p) => p['barcode'] == code).toList();
    if (match.isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(AppLanguage.english.value ? 'Barcode not found.' : 'دا بارکوډ نه دی ثبت شوی.')));
      return;
    }
    if (mounted) _add(match.first);
  }

  Future<void> _checkout(List<Map<String, Object?>> products) async {
    final en = AppLanguage.english.value;
    if (_cart.isEmpty) return;
    final customers = await BusinessService.instance.customers();
    final discountController = TextEditingController(text: '0');
    final cashController = TextEditingController(text: '${_totalFor(products)}');
    final cardController = TextEditingController(text: '0');
    String? selectedCustomer;
    String? error;
    final total = _totalFor(products);
    final result = await showDialog<Map<String, Object?>>(context: context, builder: (context) => StatefulBuilder(builder: (context, setDialog) {
      final discount = int.tryParse(discountController.text) ?? 0;
      final cash = int.tryParse(cashController.text) ?? 0;
      final card = int.tryParse(cardController.text) ?? 0;
      final credit = total - discount - cash - card;
      return AlertDialog(
        title: Text(en ? 'Complete sale' : 'خرڅلاو بشپړول'),
        content: SizedBox(
          width: 430,
          child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            _checkoutRow(en ? 'Subtotal' : 'ټولیز قیمت', _afn(total)),
            const SizedBox(height: 10),
            TextField(controller: discountController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Discount (AFN)' : 'تخفیف (AFN)'), onChanged: (_) => setDialog(() {})),
            const SizedBox(height: 10),
            TextField(controller: cashController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Cash received (AFN)' : 'ترلاسه شوې نغدې پیسې (AFN)'), onChanged: (_) => setDialog(() {})),
            const SizedBox(height: 10),
            TextField(controller: cardController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: en ? 'Card received (AFN)' : 'د کارت له لارې ترلاسه شوې پیسې (AFN)'), onChanged: (_) => setDialog(() {})),
            const SizedBox(height: 10),
            DropdownButtonFormField<String?>(
              value: selectedCustomer,
              isExpanded: true,
              decoration: InputDecoration(labelText: en ? 'Customer (required for credit)' : 'پېرودونکی (د نسیې لپاره اړین دی)'),
              items: [DropdownMenuItem<String?>(value: null, child: Text(en ? 'Walk-in customer' : 'عادي پېرودونکی')), ...customers.map((c) => DropdownMenuItem<String?>(value: c['id'] as String, child: Text('${c['name']}')))],
              onChanged: (v) => setDialog(() => selectedCustomer = v),
            ),
            const SizedBox(height: 12),
            _checkoutRow(en ? 'Remaining credit' : 'پاتې نسیه', _afn(credit.clamp(0, total))),
            if (credit < 0 || discount < 0 || discount > total || cash < 0 || card < 0) Text(en ? 'Check discount and received amount.' : 'تخفیف او ترلاسه شوې پیسې سمې کړئ.', style: const TextStyle(color: Colors.red)),
            if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
          ])),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: Text(en ? 'Cancel' : 'لغوه')),
          FilledButton(onPressed: () {
            final d = int.tryParse(discountController.text) ?? -1;
            final c = int.tryParse(cashController.text) ?? -1;
            final card = int.tryParse(cardController.text) ?? -1;
            if (d < 0 || d > total || c < 0 || card < 0 || c + card > total - d) {
              setDialog(() => error = en ? 'Amounts are invalid.' : 'د پیسو اندازه ناسمه ده.');
              return;
            }
            if (total - d - p > 0 && selectedCustomer == null) {
              setDialog(() => error = en ? 'Choose a customer for a credit sale.' : 'د نسیې خرڅلاو لپاره پېرودونکی وټاکئ.');
              return;
            }
            Navigator.pop(context, {'discount': d, 'cash': c, 'card': card, 'customer': selectedCustomer});
          }, child: Text(en ? 'Confirm' : 'تایید')),
        ],
      );
    }));
    discountController.dispose();
    cashController.dispose();
    cardController.dispose();
    if (result == null) return;
    try {
      final lines = _cart.entries.map((e) => SaleLine(productId: e.key, quantity: e.value)).toList();
      final saleId = await BusinessService.instance.createSale(
        lines: lines,
        customerId: result['customer'] as String?,
        discount: result['discount'] as int,
        cashReceived: result['cash'] as int,
        cardReceived: result['card'] as int,
      );
      if (!mounted) return;
      setState(() { _cart.clear(); _priceById.clear(); _nameById.clear(); _reload(); });
      showDialog<void>(context: context, builder: (_) => AlertDialog(
        icon: const Icon(Icons.check_circle_outline, color: Colors.green, size: 42),
        title: Text(en ? 'Sale saved' : 'خرڅلاو ثبت شو'),
        content: SelectableText('${en ? 'Receipt ID' : 'د رسید شمېره'}: $saleId\n${en ? 'Total' : 'ټول'}: ${_afn(total - (result['discount'] as int))}'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Widget _checkoutRow(String label, String value) => Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(label), Text(value, style: const TextStyle(fontWeight: FontWeight.bold))]);
  String _afn(int value) => '${NumberFormat('#,##0').format(value)} AFN';

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return FutureBuilder<List<Map<String, Object?>>>(
      future: _products,
      builder: (context, snapshot) {
        final products = snapshot.data ?? [];
        final total = _totalFor(products);
        return Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
            child: Row(children: [
              Expanded(child: TextField(controller: _search, onChanged: (_) => setState(_reload), decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: en ? 'Find product' : 'توکی ولټوئ'))),
              const SizedBox(width: 8),
              IconButton.filledTonal(onPressed: _scan, icon: const Icon(Icons.qr_code_scanner), tooltip: en ? 'Scan barcode' : 'بارکوډ سکین'),
            ]),
          ),
          Expanded(
            child: snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData
                ? const Center(child: CircularProgressIndicator())
                : ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: products.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 6),
                    itemBuilder: (context, index) {
                      final p = products[index];
                      final qty = _cart[p['id']] ?? 0;
                      return Card(child: ListTile(
                        onTap: () => _add(p),
                        title: Text(p['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${_afn(p['selling_price'] as int)} • ${en ? 'Stock' : 'سټاک'}: ${p['quantity']}'),
                        trailing: qty == 0
                            ? const Icon(Icons.add_circle_outline)
                            : Row(mainAxisSize: MainAxisSize.min, children: [
                                IconButton(onPressed: () => setState(() { if (qty == 1) { _cart.remove(p['id']); } else { _cart[p['id'] as String] = qty - 1; } }), icon: const Icon(Icons.remove_circle_outline)),
                                Text('$qty', style: const TextStyle(fontWeight: FontWeight.bold)),
                                IconButton(onPressed: () => _add(p), icon: const Icon(Icons.add_circle_outline)),
                              ]),
                      ));
                    },
                  ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
            decoration: const BoxDecoration(color: Colors.white, border: Border(top: BorderSide(color: Color(0xFFE1E7ED)))),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(en ? 'Cart total' : 'د کراچۍ ټول قیمت', style: const TextStyle(color: Colors.black54)),
                Text(_afn(total), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              ])),
              FilledButton.icon(onPressed: _cart.isEmpty || products.isEmpty ? null : () => _checkout(products), icon: const Icon(Icons.receipt_long), label: Text(en ? 'Checkout' : 'حساب بشپړول')),
            ]),
          ),
        ]);
      },
    );
  }
}
