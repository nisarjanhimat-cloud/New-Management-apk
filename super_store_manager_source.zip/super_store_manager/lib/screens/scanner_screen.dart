import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  bool _sent = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan product barcode')),
      body: MobileScanner(
        onDetect: (capture) {
          if (_sent) return;
          final code = capture.barcodes.isEmpty ? null : capture.barcodes.first.rawValue;
          if (code == null || code.isEmpty) return;
          _sent = true;
          Navigator.of(context).pop(code);
        },
      ),
    );
  }
}
