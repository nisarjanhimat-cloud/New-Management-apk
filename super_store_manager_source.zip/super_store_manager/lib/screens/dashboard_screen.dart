import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/business_service.dart';
import '../main.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<Map<String, int>> _metrics;
  final _money = NumberFormat('#,##0');

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  void _refresh() => _metrics = BusinessService.instance.dashboardMetrics();

  String _afn(int value) => '${_money.format(value)} AFN';

  @override
  Widget build(BuildContext context) {
    final en = AppLanguage.english.value;
    return RefreshIndicator(
      onRefresh: () async => setState(_refresh),
      child: FutureBuilder<Map<String, int>>(
        future: _metrics,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting && !snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) return Center(child: Text('Error: ${snapshot.error}'));
          final m = snapshot.data ?? {};
          final cards = <_MetricData>[
            _MetricData(en ? 'Products' : 'د توکو شمېر', '${m['product_count'] ?? 0}', Icons.inventory_2_outlined, const Color(0xFF155E75)),
            _MetricData(en ? 'Available units' : 'موجود مقدار', '${m['units'] ?? 0}', Icons.stacked_bar_chart, const Color(0xFF2563EB)),
            _MetricData(en ? 'Inventory cost value' : 'د اخیستلو په بیه د سټاک ارزښت', _afn(m['inventory_cost'] ?? 0), Icons.price_check, const Color(0xFF0F766E)),
            _MetricData(en ? 'Potential sales value' : 'د خرڅلاو احتمالي ارزښت', _afn(m['inventory_sales'] ?? 0), Icons.sell_outlined, const Color(0xFF7C3AED)),
            _MetricData(en ? 'Potential inventory profit' : 'د سټاک احتمالي ګټه', _afn(m['inventory_profit'] ?? 0), Icons.trending_up, const Color(0xFF15803D)),
            _MetricData(en ? 'Today sales' : 'د نن ورځې خرڅلاو', _afn(m['sales_today'] ?? 0), Icons.point_of_sale, const Color(0xFF0E7490)),
            _MetricData(en ? 'Monthly sales' : 'د میاشتې خرڅلاو', _afn(m['sales_month'] ?? 0), Icons.calendar_month, const Color(0xFF4F46E5)),
            _MetricData(en ? 'Annual sales' : 'د کال خرڅلاو', _afn(m['sales_year'] ?? 0), Icons.date_range, const Color(0xFF4338CA)),
            _MetricData(en ? 'Today expenses' : 'د نن ورځې لګښتونه', _afn(m['expense_today'] ?? 0), Icons.payments_outlined, const Color(0xFFB45309)),
            _MetricData(en ? 'Monthly expenses' : 'د میاشتې لګښتونه', _afn(m['expense_month'] ?? 0), Icons.receipt_long, const Color(0xFFB45309)),
            _MetricData(en ? 'Annual expenses' : 'د کال لګښتونه', _afn(m['expense_year'] ?? 0), Icons.receipt, const Color(0xFF92400E)),
            _MetricData(en ? 'Net profit today (estimate)' : 'د نن ورځې اټکلي خالصه ګټه', _afn(m['net_profit_today'] ?? 0), Icons.account_balance, const Color(0xFF15803D)),
            _MetricData(en ? 'Net profit this month (estimate)' : 'د دې میاشتې اټکلي خالصه ګټه', _afn(m['net_profit_month'] ?? 0), Icons.trending_up, const Color(0xFF15803D)),
            _MetricData(en ? 'Net profit this year (estimate)' : 'د دې کال اټکلي خالصه ګټه', _afn(m['net_profit_year'] ?? 0), Icons.auto_graph, const Color(0xFF166534)),
            _MetricData(en ? 'Customer debt' : 'د پېرودونکو پور', _afn(m['customer_debt'] ?? 0), Icons.person_search, const Color(0xFFB45309)),
            _MetricData(en ? 'Overdue customer debt' : 'له نېټې تېر پور', _afn(m['overdue_debt'] ?? 0), Icons.warning_amber_rounded, const Color(0xFFB91C1C)),
            _MetricData(en ? 'Supplier debt' : 'د عرضه کوونکو پور', _afn(m['supplier_debt'] ?? 0), Icons.local_shipping_outlined, const Color(0xFF7C2D12)),
            _MetricData(en ? 'Cash balance' : 'نغدي موجودي', _afn(m['cash_balance'] ?? 0), Icons.account_balance_wallet_outlined, const Color(0xFF0369A1)),
            _MetricData(en ? 'Card receipts' : 'د کارت ترلاسه شوې پیسې', _afn(m['card_balance'] ?? 0), Icons.credit_card, const Color(0xFF1D4ED8)),
            _MetricData(en ? 'Low stock products' : 'د کم سټاک توکي', '${m['low_stock'] ?? 0}', Icons.inventory, const Color(0xFFB45309)),
            _MetricData(en ? 'Expired products' : 'تاریخ تېر توکي', '${m['expired'] ?? 0}', Icons.event_busy, const Color(0xFFB91C1C)),
            _MetricData(en ? 'Expiring within 30 days' : 'په ۳۰ ورځو کې تاریخ ختمېدونکي', '${m['expiring'] ?? 0}', Icons.hourglass_bottom, const Color(0xFFCA8A04)),
          ];
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 24),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFF164E63), Color(0xFF0E7490)]),
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.storefront_rounded, color: Colors.white, size: 38),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(en ? 'Store overview' : 'د سوپرمارکېټ لنډ راپور', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 5),
                        Text(en ? 'Live figures from your local database' : 'ټولې شمېرې ستاسو له محلي ډیټابېس څخه دي', style: const TextStyle(color: Colors.white70)),
                      ]),
                    ),
                    IconButton(onPressed: () => setState(_refresh), icon: const Icon(Icons.refresh, color: Colors.white)),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: cards.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.34),
                itemBuilder: (context, index) => _MetricCard(data: cards[index]),
              ),
              const SizedBox(height: 10),
              Text(en ? 'Accounting note' : 'د حسابدارۍ یادونه', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(en
                  ? 'Sales include credit invoices. Cash balance includes only money actually received, less payments and expenses. Net profit is sales less recorded cost of goods sold and expenses; inventory purchases are not counted as an expense until sold.'
                  : 'په خرڅلاو کې نسیه خرڅلاو هم شامل دی، خو نغدي موجودي یوازې ترلاسه شوې پیسې حسابوي. خالصه ګټه د خرڅلاو له عاید څخه د پلورل شوو توکو لګښت او ثبت شوي لګښتونه منفي کوي؛ د سټاک اخیستل تر خرڅېدو پورې مستقیم مصرف نه ګڼل کېږي.'),
            ],
          );
        },
      ),
    );
  }
}

class _MetricData {
  const _MetricData(this.title, this.value, this.icon, this.color);
  final String title;
  final String value;
  final IconData icon;
  final Color color;
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({required this.data});
  final _MetricData data;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(13),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(children: [
            CircleAvatar(radius: 17, backgroundColor: data.color.withValues(alpha: 0.1), child: Icon(data.icon, color: data.color, size: 18)),
            const Spacer(),
          ]),
          Text(data.value, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800, fontSize: 15)),
          Text(data.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.black54)),
        ]),
      ),
    );
  }
}
